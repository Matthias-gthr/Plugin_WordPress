<?php
/**
 * Classe AC_Avis_Patterns
 *
 * Gère l'enregistrement des compositions de blocs (Block Patterns)
 * pour faciliter l'insertion d'avis pré-stylisés.
 *
 * @since 2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AC_Avis_Patterns {

    public function __construct() {
        add_action( 'init', [ $this, 'register_patterns' ] );
    }

    public function register_patterns() {
        // 1. Enregistrement de la catégorie de patterns
        register_block_pattern_category(
            'avis-clients',
            [ 'label' => __( 'Avis Clients Pro', 'avis-clients' ) ]
        );

        // 2. Pattern : Grille Corporate
        register_block_pattern(
            'avis-clients/grille-corporate',
            [
                'title'       => __( 'Grille d\'avis Corporate', 'avis-clients' ),
                'description' => __( 'Une grille sur 3 colonnes propre et professionnelle.', 'avis-clients' ),
                'categories'  => [ 'avis-clients' ],
                'content'     => '<!-- wp:ac/avis-query {"layout":"grid","columns":3,"schemaEntityName":"Mon Entreprise"} -->
<div class="wp-block-ac-avis-query ac-conteneur-avis ac-layout-grid ac-has-columns" style="--ac-cols:3; --ac-spv:3;"><!-- wp:ac/avis-template -->
<!-- wp:ac/avis-rating /-->
<!-- wp:ac/avis-title /-->
<!-- wp:ac/avis-content /-->
<!-- wp:ac/avis-signature {"showVerified":true,"showSource":true} /-->
<!-- /wp:ac/avis-template --></div>
<!-- /wp:ac/avis-query -->',
            ]
        );

        // 3. Pattern : Badge Agrégé + Formulaire
        register_block_pattern(
            'avis-clients/recolte-avis',
            [
                'title'       => __( 'Zone de récolte d\'avis', 'avis-clients' ),
                'description' => __( 'Affiche la note globale et un formulaire pour laisser un avis.', 'avis-clients' ),
                'categories'  => [ 'avis-clients' ],
                'content'     => '<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","orientation":"column"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">' . __( 'Ils nous font confiance', 'avis-clients' ) . '</h3>
<!-- /wp:heading -->
<!-- wp:ac/avis-query {"layout":"badge","schemaEntityName":"Mon Entreprise"} -->
<div class="wp-block-ac-avis-query ac-conteneur-avis ac-layout-badge" style="--ac-cols:3; --ac-spv:3;"></div>
<!-- /wp:ac/avis-query --></div>
<!-- /wp:group -->
<!-- wp:ac/avis-form /--></div>
<!-- /wp:group -->',
            ]
        );
    }
}
