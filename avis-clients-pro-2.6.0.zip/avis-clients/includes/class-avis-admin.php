<?php
/**
 * Classe AC_Avis_Admin
 *
 * Améliore l'écran d'administration du CPT "avis_client" :
 * - Colonnes utiles dans la liste (Note, Client, Source, Vérifié)
 * - Tri par note
 * - Badge de comptage des avis en attente (statut brouillon) sur le menu
 *
 * @since 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AC_Avis_Admin {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'ajouter_badge_menu' ], 999 );
        add_filter( 'manage_avis_client_posts_columns', [ $this, 'colonnes' ] );
        add_action( 'manage_avis_client_posts_custom_column', [ $this, 'afficher_colonne' ], 10, 2 );
        add_filter( 'manage_edit-avis_client_sortable_columns', [ $this, 'colonnes_triables' ] );
        add_action( 'pre_get_posts', [ $this, 'tri_par_note' ] );
    }

    /**
     * Ajoute un badge de comptage (style "commentaires en attente") sur
     * l'item de menu "Avis clients" quand des avis sont en statut brouillon
     * (c'est le statut donné aux soumissions du formulaire front-end).
     */
    public function ajouter_badge_menu() {
        global $menu;

        $compte = wp_count_posts( 'avis_client' );
        $en_attente = isset( $compte->draft ) ? (int) $compte->draft : 0;

        if ( ! $en_attente || ! is_array( $menu ) ) {
            return;
        }

        foreach ( $menu as $cle => $item ) {
            if ( isset( $item[2] ) && 'edit.php?post_type=avis_client' === $item[2] ) {
                $menu[ $cle ][0] .= sprintf(
                    ' <span class="awaiting-mod count-%1$d"><span class="pending-count">%1$d</span></span>',
                    $en_attente
                );
                break;
            }
        }
    }

    /**
     * Insère nos colonnes juste après le titre, avant les colonnes natives
     * (catégories, date).
     *
     * @param array $colonnes Colonnes existantes.
     * @return array
     */
    public function colonnes( $colonnes ) {
        $nouvelles = [];

        foreach ( $colonnes as $cle => $libelle ) {
            $nouvelles[ $cle ] = $libelle;

            if ( 'title' === $cle ) {
                $nouvelles['ac_note']       = __( 'Note', 'avis-clients' );
                $nouvelles['ac_nom_client'] = __( 'Client', 'avis-clients' );
                $nouvelles['ac_source']     = __( 'Source', 'avis-clients' );
                $nouvelles['ac_verified']   = __( 'Vérifié', 'avis-clients' );
            }
        }

        return $nouvelles;
    }

    /**
     * Affiche le contenu de chacune de nos colonnes personnalisées.
     *
     * @param string $colonne Clé de la colonne affichée.
     * @param int    $post_id Identifiant de l'avis.
     */
    public function afficher_colonne( $colonne, $post_id ) {
        switch ( $colonne ) {
            case 'ac_note':
                $note = max( 0, min( 5, (int) get_post_meta( $post_id, '_ac_note', true ) ) );
                echo '<span style="color:#f5a623;letter-spacing:1px;" title="' . esc_attr( sprintf(
                    /* translators: %d: note obtenue */
                    __( '%d sur 5', 'avis-clients' ),
                    $note
                ) ) . '">' . esc_html( str_repeat( '★', $note ) . str_repeat( '☆', 5 - $note ) ) . '</span>';
                break;

            case 'ac_nom_client':
                $nom = get_post_meta( $post_id, '_ac_nom_client', true );
                echo $nom ? esc_html( $nom ) : '—';
                break;

            case 'ac_source':
                $source = get_post_meta( $post_id, '_ac_source', true );
                echo $source ? esc_html( $source ) : '—';
                break;

            case 'ac_verified':
                $verified = get_post_meta( $post_id, '_ac_verified', true );
                echo ( '1' === (string) $verified )
                    ? '<span style="color:#008a20;" title="' . esc_attr__( 'Achat vérifié', 'avis-clients' ) . '">✔</span>'
                    : '—';
                break;
        }
    }

    /**
     * Déclare la colonne "Note" comme triable.
     *
     * @param array $colonnes Colonnes triables existantes.
     * @return array
     */
    public function colonnes_triables( $colonnes ) {
        $colonnes['ac_note'] = 'ac_note';
        return $colonnes;
    }

    /**
     * Traduit un tri demandé sur "ac_note" en tri par la meta _ac_note.
     *
     * @param WP_Query $query Requête de la liste d'administration.
     */
    public function tri_par_note( $query ) {
        if ( ! is_admin() || ! $query->is_main_query() ) {
            return;
        }
        if ( 'ac_note' !== $query->get( 'orderby' ) ) {
            return;
        }
        $query->set( 'meta_key', '_ac_note' );
        $query->set( 'orderby', 'meta_value_num' );
    }
}
