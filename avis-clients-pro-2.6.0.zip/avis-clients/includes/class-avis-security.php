<?php
/**
 * Classe AC_Avis_Security
 *
 * Gère la sauvegarde sécurisée des métadonnées personnalisées du CPT "avis_client".
 * Implémente les bonnes pratiques WordPress :
 * - Vérification du nonce (jeton anti-CSRF)
 * - Vérification des droits utilisateur (capabilities)
 * - Protection contre les autosaves et révisions
 * - Sanitisation de chaque champ avant enregistrement en base
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AC_Avis_Security {

    /**
     * Initialise le hook de sauvegarde.
     * Le hook 'save_post_avis_client' se déclenche uniquement pour notre CPT.
     */
    public function __construct() {
        add_action( 'save_post_avis_client', [ $this, 'sauver_meta_avis' ], 10, 2 );
    }

    /**
     * Sauvegarde les métadonnées de l'avis de manière sécurisée.
     *
     * @param int     $post_id L'identifiant du post.
     * @param WP_Post $post    L'objet post.
     */
    public function sauver_meta_avis( $post_id, $post ) {

        // ── 1. Vérification du nonce ──
        // Le nonce a été généré dans la metabox (class-avis-meta.php).
        // S'il est absent ou invalide, on refuse la sauvegarde.
        if ( ! isset( $_POST['ac_meta_nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ac_meta_nonce'] ) ), 'ac_sauver_meta_avis' ) ) {
            return;
        }

        // ── 2. Protection contre l'autosave ──
        // WordPress sauvegarde automatiquement les brouillons toutes les 60 secondes.
        // On ne veut pas écraser les meta avec des données potentiellement incomplètes.
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // ── 3. Vérification des droits utilisateur ──
        // Seuls les utilisateurs ayant la permission 'edit_post' sur cet avis
        // peuvent modifier ses métadonnées.
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // ── 4. Vérification du type de contenu ──
        // Sécurité supplémentaire : on ne traite que les avis clients.
        if ( 'avis_client' !== $post->post_type ) {
            return;
        }

        // ── 5. Sanitisation et sauvegarde de chaque champ ──

        // Note : entier entre 1 et 5
        if ( isset( $_POST['ac_note'] ) ) {
            $note = min( 5, max( 1, intval( $_POST['ac_note'] ) ) );
            update_post_meta( $post_id, '_ac_note', $note );
        }

        // Nom du client : texte simple nettoyé
        if ( isset( $_POST['ac_nom_client'] ) ) {
            $nom = sanitize_text_field( wp_unslash( $_POST['ac_nom_client'] ) );
            update_post_meta( $post_id, '_ac_nom_client', $nom );
        }

        // Date de l'avis : format date nettoyé
        if ( isset( $_POST['ac_date_avis'] ) ) {
            $date = sanitize_text_field( wp_unslash( $_POST['ac_date_avis'] ) );
            update_post_meta( $post_id, '_ac_date_avis', $date );
        }
        // Source
        if ( isset( $_POST['ac_source'] ) ) {
            $source = sanitize_text_field( wp_unslash( $_POST['ac_source'] ) );
            update_post_meta( $post_id, '_ac_source', $source );
        }

        // Achat vérifié (case à cocher)
        $verified = isset( $_POST['ac_verified'] ) ? '1' : '0';
        update_post_meta( $post_id, '_ac_verified', $verified );

        // Lien externe (préparation v2 : URL vers l'avis d'origine)
        if ( isset( $_POST['ac_lien_externe'] ) ) {
            $lien_externe = esc_url_raw( wp_unslash( $_POST['ac_lien_externe'] ) );
            update_post_meta( $post_id, '_ac_lien_externe', $lien_externe );
        }
    }
}
