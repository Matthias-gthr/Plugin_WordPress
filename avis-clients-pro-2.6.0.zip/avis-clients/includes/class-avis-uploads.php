<?php
/**
 * Classe AC_Avis_Uploads
 *
 * Autorise deux types de fichiers normalement bloqués par WordPress dans la
 * médiathèque, nécessaires aux fonctionnalités d'import des blocs (police
 * personnalisée et icône de notation SVG) :
 *
 * - Polices (.woff2/.woff/.ttf/.otf) : formats statiques, non exécutables
 *   par le navigateur. Réservé aux utilisateurs pouvant importer des médias.
 * - SVG (.svg) : format potentiellement dangereux (un SVG peut contenir du
 *   <script> ou des gestionnaires d'événements exécutés par le navigateur).
 *   Réservé aux administrateurs, et le contenu est nettoyé après l'upload
 *   avec la même liste blanche que le SVG collé à la main (cf.
 *   ac_get_rating_svg() dans src/blocks/avis-query/render.php).
 *
 * @since 2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AC_Avis_Uploads {

    public function __construct() {
        add_filter( 'upload_mimes', [ $this, 'autoriser_mimes' ] );
        add_filter( 'wp_check_filetype_and_ext', [ $this, 'corriger_filetype' ], 10, 4 );
        add_filter( 'wp_handle_upload', [ $this, 'nettoyer_svg_uploade' ] );
    }

    /**
     * Ajoute les extensions polices + SVG à la liste des types de fichiers
     * autorisés à l'upload, avec une vérification de droits par type.
     *
     * @param array $mimes Types MIME autorisés, indexés par extension(s).
     * @return array
     */
    public function autoriser_mimes( $mimes ) {

        // Polices : risque faible (contenu statique, jamais exécuté par le
        // navigateur), on autorise pour tout utilisateur pouvant uploader.
        if ( current_user_can( 'upload_files' ) ) {
            $mimes['woff2'] = 'font/woff2';
            $mimes['woff']  = 'font/woff';
            $mimes['ttf']   = 'font/ttf';
            $mimes['otf']   = 'font/otf';
        }

        // SVG : peut contenir du code exécutable, réservé aux administrateurs
        // et systématiquement nettoyé après upload (voir nettoyer_svg_uploade).
        if ( current_user_can( 'manage_options' ) ) {
            $mimes['svg'] = 'image/svg+xml';
        }

        return $mimes;
    }

    /**
     * wp_check_filetype_and_ext() s'appuie sur fileinfo pour deviner le type
     * réel du fichier, qui ne reconnaît pas toujours correctement les polices
     * et les SVG (renvoyés comme "text/plain" ou "text/xml" selon les
     * serveurs), ce qui ferait échouer l'upload malgré le filtre upload_mimes
     * ci-dessus. On revalide ces extensions uniquement sur le nom de fichier.
     */
    public function corriger_filetype( $data, $file, $filename, $mimes ) {
        $extension_autorisees = [ 'woff2', 'woff', 'ttf', 'otf', 'svg' ];
        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

        if ( in_array( $ext, $extension_autorisees, true ) && isset( $mimes[ $ext ] ) ) {
            $data['ext']  = $ext;
            $data['type'] = $mimes[ $ext ];
        }

        return $data;
    }

    /**
     * Nettoie le contenu d'un fichier SVG juste après son upload physique,
     * avec la même liste blanche stricte que ac_get_rating_svg() applique
     * au SVG collé à la main. Supprime tout <script>, gestionnaire
     * d'événement (onload, onclick…) ou référence externe avant que le
     * fichier ne reste sur le serveur.
     *
     * @param array $upload Résultat de wp_handle_upload() : ['file', 'url', 'type', ...].
     * @return array Inchangé (on modifie le fichier sur disque, pas le tableau).
     */
    public function nettoyer_svg_uploade( $upload ) {
        if ( empty( $upload['type'] ) || 'image/svg+xml' !== $upload['type'] ) {
            return $upload;
        }
        if ( empty( $upload['file'] ) || ! file_exists( $upload['file'] ) ) {
            return $upload;
        }

        $contenu = file_get_contents( $upload['file'] );
        if ( false === $contenu ) {
            return $upload;
        }

        $nettoye = wp_kses( $contenu, self::allowed_svg_tags() );
        file_put_contents( $upload['file'], $nettoye );

        return $upload;
    }

    /**
     * Liste blanche de balises/attributs SVG sûrs, partagée avec
     * ac_get_rating_svg() (src/blocks/avis-query/render.php) pour que le
     * SVG collé à la main et le SVG uploadé soient nettoyés à l'identique.
     *
     * @return array Format attendu par wp_kses().
     */
    public static function allowed_svg_tags() {
        return [
            'svg'      => [ 'class' => true, 'aria-hidden' => true, 'role' => true, 'xmlns' => true, 'width' => true, 'height' => true, 'viewBox' => true, 'fill' => true, 'opacity' => true ],
            'g'        => [ 'class' => true, 'fill' => true ],
            'path'     => [ 'class' => true, 'd' => true, 'fill' => true ],
            'circle'   => [ 'class' => true, 'cx' => true, 'cy' => true, 'r' => true, 'fill' => true ],
            'polygon'  => [ 'class' => true, 'points' => true, 'fill' => true ],
            'rect'     => [ 'class' => true, 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'fill' => true ],
        ];
    }
}
