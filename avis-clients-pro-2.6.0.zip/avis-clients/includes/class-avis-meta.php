<?php
/**
 * Classe AC_Avis_Meta
 *
 * Gère l'affichage de la metabox dans l'écran d'édition du CPT "avis_client".
 * Cette metabox permet de saisir la note, le nom du client et la date de l'avis.
 * Les champs V2 (source, id externe) sont affichés en lecture seule.
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AC_Avis_Meta {

    /**
     * Initialise les hooks WordPress nécessaires.
     */
    public function __construct() {
        add_action( 'add_meta_boxes_avis_client', [ $this, 'ajouter_metabox' ] );
    }

    /**
     * Enregistre la metabox dans l'écran d'édition.
     */
    public function ajouter_metabox() {
        add_meta_box(
            'ac_metabox_avis',                          // ID unique de la metabox
            __( 'Détails de l\'avis', 'avis-clients' ), // Titre affiché
            [ $this, 'afficher_metabox' ],              // Callback de rendu
            'avis_client',                              // CPT cible
            'normal',                                   // Position (sous l'éditeur)
            'high'                                      // Priorité d'affichage
        );
    }

    /**
     * Affiche le contenu HTML de la metabox.
     *
     * @param WP_Post $post L'objet post courant.
     */
    public function afficher_metabox( $post ) {

        // Génère un champ caché contenant un jeton de sécurité (nonce).
        // Ce jeton sera vérifié lors de la sauvegarde pour s'assurer que
        // la requête provient bien de notre formulaire et non d'une source externe.
        wp_nonce_field( 'ac_sauver_meta_avis', 'ac_meta_nonce' );

        // Récupération des valeurs actuelles en base de données
        $note        = get_post_meta( $post->ID, '_ac_note', true );
        $nom_client  = get_post_meta( $post->ID, '_ac_nom_client', true );
        $date_avis   = get_post_meta( $post->ID, '_ac_date_avis', true );
        $source        = get_post_meta( $post->ID, '_ac_source', true ) ?: 'Site';
        $verified      = get_post_meta( $post->ID, '_ac_verified', true );
        $id_externe    = get_post_meta( $post->ID, '_ac_id_externe', true );
        $lien_externe  = get_post_meta( $post->ID, '_ac_lien_externe', true );

        ?>
        <table class="form-table" role="presentation">

            <!-- Champ : Note sur 5 -->
            <tr>
                <th scope="row">
                    <label for="ac_note"><?php esc_html_e( 'Note (sur 5)', 'avis-clients' ); ?></label>
                </th>
                <td>
                    <select name="ac_note" id="ac_note">
                        <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                            <option value="<?php echo esc_attr( $i ); ?>" <?php selected( $note, $i ); ?>>
                                <?php echo str_repeat( '★', $i ) . str_repeat( '☆', 5 - $i ); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </td>
            </tr>

            <!-- Champ : Nom du client -->
            <tr>
                <th scope="row">
                    <label for="ac_nom_client"><?php esc_html_e( 'Nom du client', 'avis-clients' ); ?></label>
                </th>
                <td>
                    <input type="text"
                           name="ac_nom_client"
                           id="ac_nom_client"
                           value="<?php echo esc_attr( $nom_client ); ?>"
                           class="regular-text"
                           placeholder="<?php esc_attr_e( 'Ex : Marie Dupont', 'avis-clients' ); ?>" />
                </td>
            </tr>

            <!-- Champ : Date de l'avis -->
            <tr>
                <th scope="row">
                    <label for="ac_date_avis"><?php esc_html_e( 'Date de l\'avis', 'avis-clients' ); ?></label>
                </th>
                <td>
                    <input type="date"
                           name="ac_date_avis"
                           id="ac_date_avis"
                           value="<?php echo esc_attr( $date_avis ); ?>" />
                    <p class="description">
                        <?php esc_html_e( 'Date à laquelle le client a laissé son avis (indépendante de la date de publication WordPress).', 'avis-clients' ); ?>
                    </p>
                </td>
            </tr>

            <!-- Champ V3 : Source -->
            <tr>
                <th scope="row">
                    <label for="ac_source"><?php esc_html_e( 'Source', 'avis-clients' ); ?></label>
                </th>
                <td>
                    <select name="ac_source" id="ac_source">
                        <option value="Site" <?php selected( $source, 'Site' ); ?>>Site (Formulaire)</option>
                        <option value="Google" <?php selected( $source, 'Google' ); ?>>Google My Business</option>
                        <option value="Facebook" <?php selected( $source, 'Facebook' ); ?>>Facebook</option>
                        <option value="Trustpilot" <?php selected( $source, 'Trustpilot' ); ?>>Trustpilot</option>
                        <option value="Manuel" <?php selected( $source, 'Manuel' ); ?>>Manuel</option>
                    </select>
                </td>
            </tr>

            <!-- Champ V3 : Achat vérifié -->
            <tr>
                <th scope="row"><?php esc_html_e( 'Achat vérifié', 'avis-clients' ); ?></th>
                <td>
                    <label for="ac_verified">
                        <input type="checkbox" name="ac_verified" id="ac_verified" value="1" <?php checked( $verified, '1' ); ?> />
                        <?php esc_html_e( 'Afficher le badge "Achat vérifié"', 'avis-clients' ); ?>
                    </label>
                </td>
            </tr>

            <!-- Champ V2 : Lien externe (URL vers l'avis d'origine, ex: fiche Google) -->
            <tr>
                <th scope="row">
                    <label for="ac_lien_externe"><?php esc_html_e( 'Lien externe', 'avis-clients' ); ?></label>
                </th>
                <td>
                    <input type="url"
                           name="ac_lien_externe"
                           id="ac_lien_externe"
                           value="<?php echo esc_attr( $lien_externe ); ?>"
                           class="regular-text"
                           placeholder="https://..." />
                    <p class="description">
                        <?php esc_html_e( 'URL vers l\'avis d\'origine (ex : fiche Google, page Trustpilot). Préparation de la synchronisation externe (v2).', 'avis-clients' ); ?>
                    </p>
                </td>
            </tr>

            <?php
            // Champ V2 : ID externe (affiché uniquement si une valeur existe —
            // rempli automatiquement par une future synchronisation, pas de saisie manuelle)
            if ( ! empty( $id_externe ) ) : ?>
            <tr>
                <th scope="row"><?php esc_html_e( 'ID externe', 'avis-clients' ); ?></th>
                <td>
                    <code><?php echo esc_html( $id_externe ); ?></code>
                </td>
            </tr>
            <?php endif; ?>

        </table>
        <?php
    }
}
