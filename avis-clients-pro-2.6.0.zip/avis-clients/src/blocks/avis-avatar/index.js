/**
 * Bloc ac/avis-avatar — Éditeur Gutenberg (Vanilla JS, sans étape de build)
 *
 * Ce fichier s'appuie sur les globales WordPress exposées via wp-* :
 *   - wp.blocks      : registerBlockType
 *   - wp.blockEditor : InspectorControls, useBlockProps
 *   - wp.components  : PanelBody, RangeControl, SelectControl
 *   - wp.element     : createElement (el)
 *   - wp.i18n        : __
 *
 * Le bloc est dynamique : save() retourne null, le rendu est assuré par render.php.
 */
( function () {

    /* ── Raccourcis vers les namespaces WordPress ── */
    var registerBlockType = wp.blocks.registerBlockType;
    var el                = wp.element.createElement;
    var __                = wp.i18n.__;
    var InspectorControls = wp.blockEditor.InspectorControls;
    var useBlockProps     = wp.blockEditor.useBlockProps;
    var PanelBody         = wp.components.PanelBody;
    var RangeControl      = wp.components.RangeControl;
    var SelectControl     = wp.components.SelectControl;

    /**
     * Enregistrement du bloc ac/avis-avatar.
     *
     * Les métadonnées (name, title, icon, supports, attributes…) sont déclarées
     * dans block.json et chargées automatiquement par WordPress.
     * On surcharge ici uniquement les fonctions edit() et save().
     */
    registerBlockType( 'ac/avis-avatar', {

        /**
         * edit() — Rendu dans l'éditeur Gutenberg.
         *
         * Affiche un placeholder visuel (cercle gris avec icône personne) et
         * expose les contrôles de la barre latérale (largeur, forme).
         *
         * @param {Object} props              Propriétés du bloc.
         * @param {Object} props.attributes   Attributs courants du bloc.
         * @param {Function} props.setAttributes  Met à jour les attributs.
         */
        edit: function ( props ) {
            var attributes    = props.attributes;
            var setAttributes = props.setAttributes;

            /* Styles du placeholder : cercle gris centré */
            var placeholderStyle = {
                width           : ( attributes.width || 64 ) + 'px',
                height          : ( attributes.width || 64 ) + 'px',
                backgroundColor : '#c8c8c8',
                display         : 'flex',
                alignItems      : 'center',
                justifyContent  : 'center',
                fontSize        : Math.round( ( attributes.width || 64 ) * 0.5 ) + 'px',
                /* Forme déterminée par l'attribut shape */
                borderRadius    : attributes.shape === 'circle'
                    ? '50%'
                    : attributes.shape === 'rounded'
                        ? '12px'
                        : '0%',
                overflow        : 'hidden',
            };

            /* Propriétés du wrapper (gère automatiquement les supports) */
            var blockProps = useBlockProps( {
                style : { display: 'inline-block' },
            } );

            return el(
                wp.element.Fragment,
                null,

                /* ── Panneau de la barre latérale ── */
                el(
                    InspectorControls,
                    null,
                    el(
                        PanelBody,
                        {
                            title       : __( 'Paramètres de l\'avatar', 'avis-clients' ),
                            initialOpen : true,
                        },

                        /* Contrôle de la largeur (24 – 150 px) */
                        el( RangeControl, {
                            label    : __( 'Taille (largeur)', 'avis-clients' ),
                            value    : attributes.width,
                            onChange : function ( val ) {
                                setAttributes( { width: val } );
                            },
                            min  : 24,
                            max  : 150,
                            step : 1,
                        } ),

                        /* Contrôle de la forme de l'avatar */
                        el( SelectControl, {
                            label    : __( 'Forme', 'avis-clients' ),
                            value    : attributes.shape,
                            options  : [
                                { label: __( 'Rond',    'avis-clients' ), value: 'circle'  },
                                { label: __( 'Arrondi', 'avis-clients' ), value: 'rounded' },
                                { label: __( 'Carré',   'avis-clients' ), value: 'square'  },
                            ],
                            onChange : function ( val ) {
                                setAttributes( { shape: val } );
                            },
                        } )
                    )
                ),

                /* ── Placeholder visuel dans l'éditeur ── */
                el(
                    'div',
                    blockProps,
                    el(
                        'div',
                        { style: placeholderStyle },
                        /* Icône personne en emoji unicode */
                        el( 'span', { 'aria-hidden': 'true' }, '👤' )
                    )
                )
            );
        },

        /**
         * save() — Retourne null car le rendu est dynamique (render.php).
         * WordPress récupère le HTML côté serveur à chaque chargement de page.
         */
        save: function () {
            return null;
        },
    } );

} )();
