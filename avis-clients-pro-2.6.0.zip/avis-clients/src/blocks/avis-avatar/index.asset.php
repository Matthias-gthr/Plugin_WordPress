<?php
/**
 * Fichier d'assets généré pour le bloc ac/avis-avatar.
 * Déclare les dépendances WordPress nécessaires et la version du script
 * basée sur la date de modification du fichier index.js.
 */
return array(
    'dependencies' => array(
        'wp-element',       // Abstraction React/Preact
        'wp-blocks',        // API d'enregistrement des blocs
        'wp-i18n',          // Internationalisation
        'wp-block-editor',  // Composants de l'éditeur (InspectorControls, etc.)
        'wp-components',    // Composants UI (RangeControl, SelectControl, etc.)
    ),
    'version' => filemtime( __DIR__ . '/index.js' ),
);
