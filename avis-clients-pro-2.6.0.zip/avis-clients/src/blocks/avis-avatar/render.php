<?php
/**
 * Rendu dynamique du bloc ac/avis-avatar.
 *
 * Variables disponibles injectées par WordPress (bloc dynamique) :
 *   @var array    $attributes   Attributs du bloc (shape, width, size).
 *   @var string   $content      Contenu HTML interne (non utilisé ici).
 *   @var WP_Block $block        Instance du bloc avec les contextes hérités.
 *
 * Contexte consommé :
 *   ac/postId — Identifiant de l'avis dont on affiche l'avatar.
 */

/* ── 1. Récupération de l'ID du post depuis le contexte du bloc parent ── */
$post_id = isset( $block->context['ac/postId'] ) ? (int) $block->context['ac/postId'] : 0;

/* Si aucun post n'est associé, on n'affiche rien */
if ( ! $post_id ) {
    return;
}

/* ── 2. Vérification de l'existence d'une image à la une ── */
if ( ! has_post_thumbnail( $post_id ) ) {
    /* Pas de miniature → on abandonne silencieusement */
    return;
}

/* ── 3. Récupération des attributs du bloc ── */
$shape = isset( $attributes['shape'] ) ? $attributes['shape'] : 'circle';
$width = isset( $attributes['width'] ) ? (int) $attributes['width']  : 64;
$size  = isset( $attributes['size']  ) ? $attributes['size']          : 'thumbnail';

/* ── 4. Calcul de la border-radius selon la forme choisie ── */
switch ( $shape ) {
    case 'rounded':
        $border_radius = '12px';
        break;
    case 'square':
        $border_radius = '0%';
        break;
    case 'circle':
    default:
        $border_radius = '50%';
        break;
}

/* ── 5. Styles inline du conteneur de l'avatar ── */
$container_style = sprintf(
    'width:%dpx; height:%dpx; overflow:hidden; display:inline-block; border-radius:%s; flex-shrink:0;',
    $width,
    $width,
    esc_attr( $border_radius )
);

/* ── 6. Attributs du wrapper (classes + styles Gutenberg natifs) ── */
$wrapper_attributes = get_block_wrapper_attributes( array(
    'class' => 'ac-avis-avatar ac-avatar-' . esc_attr( $shape ),
    'style' => $container_style,
) );

/* ── 7. Récupération de la miniature avec les bons args ── */
$thumbnail_html = get_the_post_thumbnail(
    $post_id,
    $size,
    array(
        /* L'image s'étire pour remplir complètement le conteneur */
        'style' => 'width:100%; height:100%; object-fit:cover; display:block;',
        // Pas d'esc_attr() ici : get_the_post_thumbnail()/wp_get_attachment_image()
        // échappe déjà chaque attribut fourni. Le faire ici aussi double-encoderait
        // les entités (ex: "L&#039;avis" au lieu de "L'avis").
        'alt'   => get_the_title( $post_id ),
    )
);

/* ── 8. Sortie HTML ── */
echo sprintf(
    '<div %s>%s</div>',
    $wrapper_attributes,
    $thumbnail_html
);
