<?php
/**
 * Rendu dynamique du bloc ac/avis-rating.
 *
 * Variables disponibles injectées par WordPress (bloc dynamique) :
 *   @var array    $attributes   Attributs du bloc (maxRating).
 *   @var string   $content      Contenu HTML interne (non utilisé ici).
 *   @var WP_Block $block        Instance du bloc avec les contextes hérités.
 *
 * Contextes consommés (hérités du bloc parent ac/block-avis) :
 *   ac/postId        — Identifiant de l'avis.
 *   ac/starColor     — Couleur des étoiles pleines (ex: "#f5a623").
 *   ac/ratingIcon    — Type d'icône (star, heart, thumb, fire, etc.).
 *   ac/customStarSvg — SVG personnalisé si ratingIcon === 'custom'.
 *
 * La fonction ac_get_rating_svg() est définie dans block-avis/render.php.
 * Ce fichier étant chargé après, on vérifie son existence avant de l'appeler.
 */

/* ── 1. Récupération du contexte hérité ── */
$post_id        = isset( $block->context['ac/postId'] )        ? (int)    $block->context['ac/postId']        : 0;

/* ── 2. Lecture des attributs du bloc ── */
$max_rating     = isset( $attributes['maxRating'] )     ? (int) $attributes['maxRating'] : 5;
$star_color     = isset( $attributes['starColor'] )     ? sanitize_hex_color( $attributes['starColor'] ) : '#f5a623';
$rating_icon    = isset( $attributes['ratingIcon'] )    ? sanitize_key( $attributes['ratingIcon'] )      : 'star';
$custom_star_svg= isset( $attributes['customStarSvg'] ) ? $attributes['customStarSvg']                 : '';
$custom_star_svg_url = isset( $attributes['customStarSvgUrl'] ) ? esc_url_raw( $attributes['customStarSvgUrl'] ) : '';

/* ── 3. Récupération de la note enregistrée en méta-donnée du post ── */
$note = 0;
if ( $post_id ) {
    $meta = get_post_meta( $post_id, '_ac_note', true );
    /* On s'assure d'avoir un entier entre 0 et max_rating */
    $note = max( 0, min( $max_rating, (int) $meta ) );
}

/* Si aucun post n'est lié, on n'affiche rien */
if ( ! $post_id ) {
    return;
}

/* ── 4. Génération des SVG via la fonction partagée ac_get_rating_svg() ── */
$svg_plein = '';
$svg_vide  = '';

if ( function_exists( 'ac_get_rating_svg' ) ) {
    /* SVG pour une étoile remplie (filled = true) */
    $svg_plein = ac_get_rating_svg( $rating_icon, true,  $custom_star_svg, $custom_star_svg_url );
    /* SVG pour une étoile vide / grisée (filled = false, opacité 0.2) */
    $svg_vide  = ac_get_rating_svg( $rating_icon, false, $custom_star_svg, $custom_star_svg_url );
} else {
    /*
     * Fallback si la fonction n'est pas encore disponible (ex : chargement
     * partiel lors de l'édition dans l'éditeur de site).
     * On utilise un SVG étoile minimal.
     */
    $svg_plein = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" opacity="1"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
    $svg_vide  = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" opacity="0.2"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>';
}

/* ── 5. Construction des attributs du wrapper ── */
$aria_label = sprintf(
    /* translators: 1: note obtenue, 2: note maximale */
    __( 'Note %1$d sur %2$d', 'avis-clients' ),
    $note,
    $max_rating
);

$wrapper_attributes = get_block_wrapper_attributes( array(
    'class'      => 'ac-avis-etoiles',
    /*
     * La couleur des étoiles est appliquée via `color: ...` sur le conteneur.
     * Les SVG utilisent fill="currentColor" → ils héritent automatiquement.
     */
    'style'      => 'color:' . esc_attr( $star_color ) . ';',
    'aria-label' => esc_attr( $aria_label ),
    'role'       => 'img',
) );

/* ── 6. Construction du HTML des étoiles ── */
$etoiles_html = '';

for ( $i = 1; $i <= $max_rating; $i++ ) {
    if ( $i <= $note ) {
        /* Étoile pleine : l'avis a au moins cette valeur */
        $etoiles_html .= '<span class="ac-etoile ac-etoile--pleine" aria-hidden="true">' . $svg_plein . '</span>';
    } else {
        /* Étoile vide : au-delà de la note obtenue */
        $etoiles_html .= '<span class="ac-etoile ac-etoile--vide" aria-hidden="true">' . $svg_vide . '</span>';
    }
}

echo sprintf(
    '<div %s><div class="ac-rating-stars-inner" style="color:%s">%s</div></div>',
    $wrapper_attributes,
    esc_attr( $star_color ),
    $etoiles_html
);
