/**
 * Bloc ac/avis-rating — Éditeur Gutenberg (Vanilla JS, sans étape de build)
 *
 * Panneau de personnalisation de la notation :
 *   - Note maximale (maxRating)
 *   - Icône de notation (ratingIcon) : grille visuelle étoile/cœur/pouce/feu/
 *     check/diamant/couronne/sourire, ou "Personnalisé" (SVG collé à la main
 *     OU importé via la médiathèque, cf. ratingIcon === 'custom')
 *   - Couleur des étoiles (starColor)
 *
 * Toutes ces options vivaient dans le bloc parent (avis-query) en V1.
 * En V2, elles appartiennent logiquement au bloc qui les affiche.
 */
( function () {

    /* ── Raccourcis vers les namespaces WordPress ── */
    var registerBlockType  = wp.blocks.registerBlockType;
    var el                 = wp.element.createElement;
    var Fragment           = wp.element.Fragment;
    var __                 = wp.i18n.__;
    var InspectorControls  = wp.blockEditor.InspectorControls;
    var useBlockProps      = wp.blockEditor.useBlockProps;
    var PanelBody          = wp.components.PanelBody;
    var RangeControl       = wp.components.RangeControl;
    var TextareaControl    = wp.components.TextareaControl;
    var BaseControl        = wp.components.BaseControl;
    var Button             = wp.components.Button;
    var MediaUpload        = wp.blockEditor.MediaUpload;
    var MediaUploadCheck   = wp.blockEditor.MediaUploadCheck;
    var PanelColorSettings = wp.blockEditor.PanelColorSettings;

    /* Icônes de base — chemins SVG identiques à ceux générés côté serveur
     * par ac_get_rating_svg() (src/blocks/avis-query/render.php), pour que
     * l'aperçu dans l'éditeur corresponde exactement au rendu front. */
    var RATING_ICONS = [
        { value: 'star',    label: __( 'Étoile', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>' },
        { value: 'heart',   label: __( 'Cœur', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>' },
        { value: 'thumb',   label: __( 'Pouce', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"/></svg>' },
        { value: 'fire',    label: __( 'Feu', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M13.73 2c-1.3 3.32-3.13 6.01-5.65 8.35C5.24 12.06 4 14.07 4 16.27c0 4.8 3.96 8.73 8.79 8.73 4.83 0 8.79-3.93 8.79-8.73 0-3.32-1.87-6.28-4.66-7.85z"/></svg>' },
        { value: 'check',   label: __( 'Check', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>' },
        { value: 'diamond', label: __( 'Diamant', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 2L2 9l10 13 10-13L12 2z"/></svg>' },
        { value: 'crown',   label: __( 'Couronne', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M2 20h20v2H2zM2 5l5 4 5-7 5 7 5-4v13H2V5z"/></svg>' },
        { value: 'smile',   label: __( 'Sourire', 'avis-clients' ),
          svg: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round"/><circle cx="9" cy="9" r="1.5" fill="currentColor"/><circle cx="15" cy="9" r="1.5" fill="currentColor"/></svg>' },
    ];

    /* Grille de boutons visuels pour choisir l'icône (remplace le menu texte
     * déroulant). Le dernier bouton "Personnalisé" ouvre les options
     * d'import (coller du code ou importer un fichier .svg). */
    function renderIconPicker( attributes, setAttributes ) {
        var current = attributes.ratingIcon || 'star';

        function iconButton( icon ) {
            var isActive = current === icon.value;
            return el( Button, {
                key: icon.value,
                onClick: function () { setAttributes( { ratingIcon: icon.value } ); },
                'aria-pressed': isActive,
                label: icon.label,
                showTooltip: true,
                style: {
                    width: '38px', height: '38px', display: 'flex',
                    alignItems: 'center', justifyContent: 'center',
                    border: isActive ? '2px solid #007cba' : '1px solid #ddd',
                    borderRadius: '4px',
                    background: isActive ? '#e5f5fa' : '#fff',
                    color: isActive ? '#007cba' : '#1e1e1e',
                },
            /* dangerouslySetInnerHTML doit être sur un enfant dédié, jamais
             * directement sur Button : ce composant fournit toujours ses
             * propres enfants (tooltip...), et React interdit d'avoir à la
             * fois `children` et `dangerouslySetInnerHTML` sur un même
             * élément (erreur fatale qui casse tout le rendu du bloc). */
            }, el( 'span', {
                style: { display: 'flex', width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center' },
                dangerouslySetInnerHTML: { __html: icon.svg },
            } ) );
        }

        return el( BaseControl, { label: __( 'Icône', 'avis-clients' ), __nextHasNoMarginBottom: true },
            el( 'div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px' } },
                RATING_ICONS.map( iconButton ),
                el( Button, {
                    onClick: function () { setAttributes( { ratingIcon: 'custom' } ); },
                    'aria-pressed': current === 'custom',
                    label: __( 'Personnalisé', 'avis-clients' ),
                    showTooltip: true,
                    style: {
                        width: '38px', height: '38px', display: 'flex',
                        alignItems: 'center', justifyContent: 'center',
                        border: current === 'custom' ? '2px solid #007cba' : '1px solid #ddd',
                        borderRadius: '4px',
                        background: current === 'custom' ? '#e5f5fa' : '#fff',
                        color: current === 'custom' ? '#007cba' : '#1e1e1e',
                        fontSize: '16px',
                    },
                }, '✏️' )
            )
        );
    }

    /* Options d'icône personnalisée : coller du code SVG OU importer un
     * fichier .svg via la médiathèque. Les deux sont mutuellement exclusifs
     * pour éviter toute ambiguïté sur celui qui s'applique réellement (le
     * rendu PHP donne la priorité au code collé, voir ac_get_rating_svg()). */
    function renderCustomSvgControls( attributes, setAttributes ) {
        var hasFile = !! attributes.customStarSvgUrl;
        var hasCode = !! attributes.customStarSvg;

        return el( Fragment, null,
            el( TextareaControl, {
                label:    __( 'Coller le code SVG', 'avis-clients' ),
                value:    attributes.customStarSvg,
                rows:     4,
                help:     hasFile
                    ? __( 'Prioritaire sur le fichier importé ci-dessous si rempli.', 'avis-clients' )
                    : __( 'Collez ici votre balise <svg>…</svg>.', 'avis-clients' ),
                onChange: function ( v ) { setAttributes( { customStarSvg: v } ); },
            } ),
            el( 'div', { style: { margin: '8px 0', fontSize: '11px', color: '#757575', textAlign: 'center' } }, __( '— ou —', 'avis-clients' ) ),
            el( MediaUploadCheck, null,
                el( MediaUpload, {
                    onSelect: function ( media ) {
                        setAttributes( { customStarSvgUrl: media.url, customStarSvg: '' } );
                    },
                    allowedTypes: [ 'image/svg+xml' ],
                    render: function ( obj ) {
                        return el( Button, {
                            variant: 'secondary',
                            onClick: obj.open,
                        }, hasFile
                            ? __( 'Changer le fichier SVG', 'avis-clients' )
                            : __( 'Importer un fichier .svg', 'avis-clients' )
                        );
                    },
                } )
            ),
            hasFile && el( 'div', { style: { marginTop: '6px', fontSize: '12px' } },
                el( 'code', {}, attributes.customStarSvgUrl.split( '/' ).pop() ),
                ' — ',
                el( Button, {
                    variant: 'link',
                    isDestructive: true,
                    onClick: function () { setAttributes( { customStarSvgUrl: '' } ); },
                }, __( 'Retirer', 'avis-clients' ) )
            ),
            hasCode && hasFile && el( 'p', { style: { fontSize: '11px', color: '#b32d2e', marginTop: '6px' } },
                __( 'Le code SVG collé ci-dessus est utilisé en priorité ; videz-le pour utiliser le fichier importé.', 'avis-clients' )
            ),
            el( 'p', { style: { fontSize: '11px', color: '#757575', marginTop: '4px' } },
                __( 'Réservé aux administrateurs : le fichier est nettoyé (scripts retirés) automatiquement après import.', 'avis-clients' )
            )
        );
    }

    registerBlockType( 'ac/avis-rating', {

        edit: function ( props ) {
            var attributes    = props.attributes;
            var setAttributes = props.setAttributes;

            /* Propriétés du wrapper (gère automatiquement les supports typographie, couleur…) */
            var blockProps = useBlockProps( {
                style: { display: 'inline-flex', alignItems: 'center', gap: '2px' },
            } );

            /* Génère le placeholder visuel avec la vraie couleur choisie */
            var stars = [];
            for ( var i = 0; i < ( attributes.maxRating || 5 ); i++ ) {
                stars.push(
                    el( 'span', {
                        key: i,
                        style: {
                            color:     attributes.starColor || '#f5a623',
                            fontSize:  '1.4em',
                            lineHeight: '1',
                        },
                        'aria-hidden': 'true',
                    }, '★' )
                );
            }

            /* ── Panneau de notation complet (anciennement dans avis-query) ── */
            var panelRating = el(
                PanelBody,
                {
                    title:       __( 'Paramètres de notation', 'avis-clients' ),
                    initialOpen: true,
                },

                /* Note maximale */
                el( RangeControl, {
                    label:    __( 'Note maximale', 'avis-clients' ),
                    value:    attributes.maxRating,
                    min:      1,
                    max:      5,
                    step:     1,
                    onChange: function ( v ) { setAttributes( { maxRating: v } ); },
                } ),

                /* Icône de notation — grille visuelle */
                renderIconPicker( attributes, setAttributes ),

                /* Options d'icône personnalisée — visible uniquement si "Personnalisé" est actif */
                attributes.ratingIcon === 'custom' && renderCustomSvgControls( attributes, setAttributes )
            );

            /* Couleur des étoiles — composant natif WordPress (palette du
             * thème). Reste affiché en permanence (comportement natif des
             * versions récentes de Gutenberg), c'est assumé. */
            var panelColor = el(
                PanelColorSettings,
                {
                    title: __( 'Couleur', 'avis-clients' ),
                    initialOpen: true,
                    colorSettings: [
                        {
                            value: attributes.starColor,
                            onChange: function ( v ) { setAttributes( { starColor: v || '#f5a623' } ); },
                            label: __( 'Étoiles', 'avis-clients' ),
                        },
                    ],
                }
            );

            return el(
                Fragment,
                null,
                /* Panneau de la barre latérale */
                el( InspectorControls, null, panelRating, panelColor ),
                /* Placeholder visuel dans le canvas : étoiles avec la vraie couleur */
                el( 'div', blockProps, stars )
            );
        },

        /* save() — Retourne null car le rendu est dynamique (render.php). */
        save: function () {
            return null;
        },
    } );

} )();
