/**
 * Bloc « Avis Template » — Éditeur Gutenberg
 *
 * Modèle de carte. Contient les blocs enfants (avatar, étoiles, titre, texte, signature).
 * La sidebar Gutenberg native (supports) gère le style de base de la carte.
 * Des panneaux custom gèrent le hover (B3) et l'ombre avancée (B4).
 *
 * Vanilla JS — aucun build requis.
 */
(function () {
    'use strict';

    /* ── Imports WordPress ── */
    var el                = wp.element.createElement;
    var Fragment          = wp.element.Fragment;
    var registerBlockType = wp.blocks.registerBlockType;
    var InnerBlocks       = wp.blockEditor.InnerBlocks;
    var useBlockProps     = wp.blockEditor.useBlockProps;
    var InspectorControls = wp.blockEditor.InspectorControls;
    var __                = wp.i18n.__;
    var PanelBody         = wp.components.PanelBody;
    var SelectControl     = wp.components.SelectControl;
    var RangeControl      = wp.components.RangeControl;
    var Notice            = wp.components.Notice;
    var PanelColorSettings= wp.blockEditor.PanelColorSettings;

    /* Blocs autorisés dans la carte */
    var ALLOWED_BLOCKS = [
        'ac/avis-avatar',
        'ac/avis-rating',
        'ac/avis-title',
        'ac/avis-content',
        'ac/avis-signature',
    ];

    /* Template par défaut de la carte */
    var CARD_TEMPLATE = [
        ['ac/avis-avatar',    {}],
        ['ac/avis-rating',    {}],
        ['ac/avis-title',     {}],
        ['ac/avis-content',   {}],
        ['ac/avis-signature', {}],
    ];

    /* ══════════════════════════════════════════
       Composant Edit
       ══════════════════════════════════════════ */
    function EditAvisTemplate(props) {
        var attributes    = props.attributes;
        var setAttributes = props.setAttributes;

        /* useBlockProps applique les styles natifs Gutenberg
         * (bordure, padding, couleur de fond, arrondi, ombre…) */
        var blockProps = useBlockProps({ className: 'ac-carte-avis' });

        /* ── Panneau : Apparence de la carte (arrondi + espacement) ──
         * Contrôles "de secours" : le panneau natif "Bordure" et le réglage
         * natif "Espacement des blocs" sont bien déclarés et autorisés par
         * le thème (vérifié), mais n'apparaissent/n'agissent pas de façon
         * fiable sur ce bloc dans cet environnement. Ces deux réglages
         * appliquent directement le style en CSS inline, donc fonctionnent
         * à coup sûr quel que soit ce problème natif. */
        var panelApparence = el(
            PanelBody,
            {
                title: __('Apparence de la carte', 'avis-clients'),
                initialOpen: false,
            },
            el(RangeControl, {
                label: __('Arrondi des coins (px)', 'avis-clients'),
                value: attributes.cardBorderRadius,
                onChange: function (v) { setAttributes({ cardBorderRadius: v }); },
                min: 0,
                max: 60,
            }),
            el(RangeControl, {
                label: __('Espacement entre les blocs enfants (px)', 'avis-clients'),
                help: __('Espace entre avatar, étoiles, titre, texte et signature à l\'intérieur de la carte.', 'avis-clients'),
                value: attributes.cardGap,
                onChange: function (v) { setAttributes({ cardGap: v }); },
                min: 0,
                max: 60,
            })
        );

        /* ── Panneau B3 : Effets de survol ── */
        var panelHover = el(
            PanelBody,
            {
                title: __('Effets de survol', 'avis-clients'),
                initialOpen: false,
            },
            el(SelectControl, {
                label: __('Animation', 'avis-clients'),
                value: attributes.hoverAnimation,
                options: [
                    { value: 'none',  label: __('Aucune', 'avis-clients') },
                    { value: 'lift',  label: __('Élévation (lift)', 'avis-clients') },
                    { value: 'scale', label: __('Zoom (scale)', 'avis-clients') },
                    { value: 'glow',  label: __('Lueur (glow)', 'avis-clients') },
                    { value: 'tilt',  label: __('Inclinaison (tilt)', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ hoverAnimation: v }); },
                help: __('Type de mouvement au survol de la carte.', 'avis-clients'),
            }),
            /* Intensité : visible sauf si "aucune" */
            attributes.hoverAnimation !== 'none' && el(RangeControl, {
                label: __('Intensité', 'avis-clients'),
                value: attributes.hoverIntensity,
                onChange: function (v) { setAttributes({ hoverIntensity: v }); },
                min: 1,
                max: 10,
            }),
            /* Vitesse */
            attributes.hoverAnimation !== 'none' && el(SelectControl, {
                label: __('Vitesse de transition', 'avis-clients'),
                value: attributes.hoverSpeed,
                options: [
                    { value: 'slow',   label: __('Lente (0.5s)', 'avis-clients') },
                    { value: 'normal', label: __('Normale (0.3s)', 'avis-clients') },
                    { value: 'fast',   label: __('Rapide (0.15s)', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ hoverSpeed: v }); },
            })
        );

        /* Couleurs de survol : composant natif WordPress (palette du thème).
         * Reste affiché en permanence (comportement natif des versions
         * récentes de Gutenberg), c'est assumé. */
        var panelHoverColors = el(
            PanelColorSettings,
            {
                title: __('Couleurs de survol', 'avis-clients'),
                initialOpen: false,
                colorSettings: [
                    {
                        value: attributes.hoverBackground,
                        onChange: function (v) { setAttributes({ hoverBackground: v || '' }); },
                        label: __('Fond au survol', 'avis-clients'),
                    },
                    {
                        value: attributes.hoverBorderColor,
                        onChange: function (v) { setAttributes({ hoverBorderColor: v || '' }); },
                        label: __('Bordure au survol', 'avis-clients'),
                    },
                    {
                        value: attributes.hoverTextColor,
                        onChange: function (v) { setAttributes({ hoverTextColor: v || '' }); },
                        label: __('Texte au survol', 'avis-clients'),
                    },
                ],
            }
        );

        /* ── Panneau B4 : Ombre avancée ── */
        var panelShadow = el(
            PanelBody,
            {
                title: __('Ombre avancée', 'avis-clients'),
                initialOpen: false,
            },
            el('p', {
                style: { fontSize: '12px', color: '#757575', marginTop: 0, marginBottom: '12px' }
            }, __('Complète l\'ombre native de la sidebar. Laissez vide pour désactiver.', 'avis-clients')),
            el(RangeControl, {
                label: __('Décalage X (px)', 'avis-clients'),
                value: attributes.shadowOffsetX,
                onChange: function (v) { setAttributes({ shadowOffsetX: v }); },
                min: -50, max: 50,
            }),
            el(RangeControl, {
                label: __('Décalage Y (px)', 'avis-clients'),
                value: attributes.shadowOffsetY,
                onChange: function (v) { setAttributes({ shadowOffsetY: v }); },
                min: -50, max: 50,
            }),
            el(RangeControl, {
                label: __('Flou (px)', 'avis-clients'),
                value: attributes.shadowBlur,
                onChange: function (v) { setAttributes({ shadowBlur: v }); },
                min: 0, max: 100,
            }),
            el(RangeControl, {
                label: __('Étendue (px)', 'avis-clients'),
                value: attributes.shadowSpread,
                onChange: function (v) { setAttributes({ shadowSpread: v }); },
                min: -20, max: 50,
            })
        );

        /* Couleur d'ombre : même logique que panelHoverColors ci-dessus. */
        var panelShadowColor = el(
            PanelColorSettings,
            {
                title: __('Couleur de l\'ombre', 'avis-clients'),
                initialOpen: false,
                colorSettings: [
                    {
                        value: attributes.shadowColor,
                        onChange: function (v) { setAttributes({ shadowColor: v || '' }); },
                        label: __('Couleur', 'avis-clients'),
                    },
                ],
            }
        );

        /* ── Notice B1/B2 : guide drag-and-drop ── */
        var noticeHelp = el(
            Notice,
            {
                status: 'info',
                isDismissible: false,
                style: { margin: '8px 16px 0', fontSize: '12px' },
            },
            el('strong', {}, __('Visibilité & ordre', 'avis-clients')),
            ' — ',
            __('Supprimez un bloc enfant pour le masquer. Glissez-le pour le réordonner.', 'avis-clients')
        );

        return el(
            Fragment,
            null,

            /* Panneaux sidebar */
            el(InspectorControls, null,
                noticeHelp,
                panelApparence,
                panelHover,
                panelHoverColors,
                panelShadow,
                panelShadowColor
            ),

            /* Note visuelle au-dessus de la carte dans l'éditeur */
            el('div', {
                style: {
                    fontSize: '10px', color: '#999', fontStyle: 'italic',
                    marginBottom: '4px', paddingLeft: '4px',
                },
            }, '↩ Modèle de carte — répété pour chaque avis'),

            /* Wrapper de la carte avec les styles natifs (supports) */
            el('div', blockProps,
                /* Blocs enfants éditables dans le canvas — templateLock: false
                 * permet le drag-and-drop natif et la suppression individuelle */
                el(InnerBlocks, {
                    allowedBlocks: ALLOWED_BLOCKS,
                    template: CARD_TEMPLATE,
                    templateLock: false,
                    orientation: 'vertical',
                })
            )
        );
    }

    /* ══════════════════════════════════════════
       Enregistrement du bloc
       ══════════════════════════════════════════ */
    registerBlockType('ac/avis-template', {
        edit: EditAvisTemplate,

        /* save() retourne InnerBlocks.Content pour que la structure
         * des blocs enfants soit persistée en base de données. */
        save: function () {
            return el(InnerBlocks.Content, null);
        },
    });

})();
