<?php
/**
 * Rendu PHP du bloc « ac/avis-template »
 *
 * Ce bloc est répété autant de fois que de posts par avis-query/render.php.
 * Il reçoit 'ac/postId' dans son contexte (injecté par WP_Block instancié avec context).
 *
 * $content contient déjà le HTML rendu de tous les inner blocks (avatar, étoiles, titre…)
 * car WordPress les a rendus automatiquement avec le contexte du post courant.
 *
 * B3 : Les effets de survol sont injectés via des variables CSS --ac-hover-*
 * B4 : L'ombre avancée custom est injectée comme box-shadow inline.
 */

// Identifiant du post depuis le contexte injecté par ac/avis-query
$post_id = isset( $block->context['ac/postId'] ) ? intval( $block->context['ac/postId'] ) : 0;

if ( ! $post_id ) {
    return ''; // Contexte manquant, on ne rend rien
}

// Source de l'avis (ex: Google, Trustpilot…) pour la classe CSS
$source       = get_post_meta( $post_id, '_ac_source', true );
$source_class = $source ? 'ac-source-' . sanitize_html_class( $source ) : '';


/* ── B3 : Animation de survol ── */
$hover_animation = isset( $attributes['hoverAnimation'] ) && $attributes['hoverAnimation'] !== '' ? sanitize_key( $attributes['hoverAnimation'] ) : 'none';
$hover_intensity = isset( $attributes['hoverIntensity'] ) ? intval( $attributes['hoverIntensity'] ) : 5;
$hover_speed_map = [ 'slow' => '0.5s', 'normal' => '0.3s', 'fast' => '0.15s', 'spring' => '0.4s' ];
$hover_speed_key = isset( $attributes['hoverSpeed'] ) ? $attributes['hoverSpeed'] : 'normal';
$hover_speed     = isset( $hover_speed_map[ $hover_speed_key ] ) ? $hover_speed_map[ $hover_speed_key ] : '0.3s';

/* Classe CSS de survol : ac-hover-lift, ac-hover-scale, ac-hover-glow, ac-hover-tilt */
$hover_class = ( $hover_animation !== 'none' ) ? 'ac-hover-' . $hover_animation : '';

/* Construction du style inline avec les variables CSS hover et shadow */
$inline_vars = sprintf(
    '--ac-hover-speed:%s; --ac-hover-intensity:%d;',
    esc_attr( $hover_speed ),
    $hover_intensity
);

if ( ! empty( $attributes['hoverBackground'] ) ) {
    $inline_vars .= ' --ac-hover-bg:' . esc_attr( $attributes['hoverBackground'] ) . ';';
}
if ( ! empty( $attributes['hoverBorderColor'] ) ) {
    $inline_vars .= ' --ac-hover-border:' . esc_attr( $attributes['hoverBorderColor'] ) . ';';
}
if ( ! empty( $attributes['hoverTextColor'] ) ) {
    $inline_vars .= ' --ac-hover-text:' . esc_attr( $attributes['hoverTextColor'] ) . ';';
}

/* ── B4 : Ombre avancée ── */
if ( ! empty( $attributes['shadowColor'] ) && $attributes['shadowColor'] !== 'rgba(0,0,0,0)' ) {
    $sx = isset( $attributes['shadowOffsetX'] ) ? intval( $attributes['shadowOffsetX'] ) : 0;
    $sy = isset( $attributes['shadowOffsetY'] ) ? intval( $attributes['shadowOffsetY'] ) : 4;
    $sb = isset( $attributes['shadowBlur'] ) ? intval( $attributes['shadowBlur'] ) : 12;
    $ss = isset( $attributes['shadowSpread'] ) ? intval( $attributes['shadowSpread'] ) : 0;
    $sc = $attributes['shadowColor'];
    $inline_vars .= ' box-shadow:' . $sx . 'px ' . $sy . 'px ' . $sb . 'px ' . $ss . 'px ' . esc_attr( $sc ) . ';';
}

/* Arrondi des coins + espacement entre blocs enfants : appliqués en style
 * inline avec !important. Le panneau natif "Bordure"/"Espacement des blocs"
 * ne s'affichant pas de façon fiable pour ce bloc dans certains environnements
 * (vérifié : le bloc ET le thème autorisent bien la fonctionnalité), ces
 * deux réglages custom garantissent un résultat quel que soit ce problème. */
$card_border_radius = isset( $attributes['cardBorderRadius'] ) ? intval( $attributes['cardBorderRadius'] ) : 16;
$card_gap            = isset( $attributes['cardGap'] ) ? intval( $attributes['cardGap'] ) : 20;
$inline_vars .= ' border-radius:' . $card_border_radius . 'px !important; gap:' . $card_gap . 'px !important;';

/* Classe CSS de base de la carte */
$card_class = trim( implode( ' ', array_filter( [ 'ac-carte-avis', $source_class, $hover_class ] ) ) );

/* get_block_wrapper_attributes() fusionne automatiquement :
 * - La classe passée en argument
 * - Les classes générées par les supports natifs (couleur, bordure, etc.)
 * - Les styles inline générés par les supports (padding, border-radius, etc.) */
$wrapper_attrs = get_block_wrapper_attributes([
    'class' => $card_class,
    'style' => $inline_vars,
]);

// $content = HTML des inner blocks déjà rendus avec le bon contexte de post
echo sprintf( '<div %s>%s</div>', $wrapper_attrs, $content );
