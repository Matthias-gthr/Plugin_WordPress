<?php
/* Dépendances du script éditeur du bloc ac/avis-template.
 * Inclut wp-components pour Notice, SelectControl, RangeControl (B3/B4).
 * Version préfixée pour forcer le cache-busting. */
return array(
    'dependencies' => array(
        'wp-element',
        'wp-blocks',
        'wp-i18n',
        'wp-block-editor',
        'wp-components',
    ),
    'version' => '2.1.' . filemtime( __DIR__ . '/index.js' ),
);
