<?php
/* Déclaration des dépendances WordPress pour le script de l'éditeur.
 * La version est calculée sur le timestamp du fichier JS pour forcer
 * le rechargement du cache navigateur à chaque modification. */
return array(
    'dependencies' => array(
        'wp-element',
        'wp-blocks',
        'wp-i18n',
        'wp-block-editor',
        'wp-components',
        'wp-data',
        'wp-server-side-render',
    ),
    'version' => '2.1.2.' . filemtime( __DIR__ . '/index.js' ),
);
