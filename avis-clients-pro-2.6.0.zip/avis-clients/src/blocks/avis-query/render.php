<?php
/**
 * Rendu PHP du bloc « ac/avis-query »
 *
 * Variables automatiquement disponibles (apiVersion 3 + render.php) :
 *   $attributes (array)  — attributs du bloc
 *   $content    (string) — inner blocks sauvegardés (non utilisé directement)
 *   $block      (WP_Block) — instance du bloc, donne accès à $block->inner_blocks
 *
 * Flux de rendu :
 *   1. On exécute la WP_Query avec les filtres du bloc
 *   2. On récupère le bloc ac/avis-template depuis $block->inner_blocks
 *   3. Pour chaque post, on instancie un nouveau WP_Block avec le contexte du post
 *   4. Le bloc template rend ses propres inner blocks (avatar, étoiles, titre, etc.)
 *      chacun avec le bon post ID dans le contexte
 */

// Définition de la fonction SVG uniquement si elle n'est pas déjà disponible.
// Cela évite d'inclure le fichier render.php de l'ancien bloc (qui exécuterait du code parasite).
if ( ! function_exists( 'ac_get_rating_svg' ) ) {
    /**
     * Génère un SVG d'icône de notation (rempli ou vide).
     * @param string $icon_type      Type d'icône (star, heart, thumb…) ou 'custom'.
     * @param bool   $filled         Rempli (true) ou vide (false, opacité 0.2)
     * @param string $custom_svg     Code SVG collé à la main (si $icon_type === 'custom')
     * @param string $custom_svg_url Fichier SVG importé via la médiathèque (utilisé si $custom_svg est vide)
     * @return string HTML du SVG
     */
    function ac_get_rating_svg( $icon_type, $filled = true, $custom_svg = '', $custom_svg_url = '' ) {
        $opacity = $filled ? '1' : '0.2';
        if ( $icon_type === 'custom' ) {
            // Le code collé à la main est prioritaire ; sinon on lit le fichier importé.
            if ( empty( $custom_svg ) && ! empty( $custom_svg_url ) ) {
                $custom_svg = ac_lire_svg_importe( $custom_svg_url );
            }
            if ( ! empty( $custom_svg ) ) {
                // Sécurité : nettoyage du SVG (liste blanche partagée avec l'upload, voir
                // AC_Avis_Uploads::allowed_svg_tags() dans includes/class-avis-uploads.php).
                $allowed = class_exists( 'AC_Avis_Uploads' ) ? AC_Avis_Uploads::allowed_svg_tags() : [];
                if ( ! $filled ) {
                    $custom_svg = preg_replace( '/<svg([^>]+)>/i', '<svg$1 opacity="0.2">', wp_kses( $custom_svg, $allowed ) );
                    return $custom_svg;
                }
                return wp_kses( $custom_svg, $allowed );
            }
        }
        switch ( $icon_type ) {
            case 'heart':
                $d = 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'; break;
            case 'thumb':
                $d = 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z'; break;
            case 'fire':
                $d = 'M13.73 2c-1.3 3.32-3.13 6.01-5.65 8.35C5.24 12.06 4 14.07 4 16.27c0 4.8 3.96 8.73 8.79 8.73 4.83 0 8.79-3.93 8.79-8.73 0-3.32-1.87-6.28-4.66-7.85z'; break;
            case 'check':
                $d = 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z'; break;
            case 'diamond':
                $d = 'M12 2L2 9l10 13 10-13L12 2z'; break;
            case 'crown':
                $d = 'M2 20h20v2H2zM2 5l5 4 5-7 5 7 5-4v13H2V5z'; break;
            case 'smile':
                return '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" opacity="' . $opacity . '"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round"/><circle cx="9" cy="9" r="1.5" fill="currentColor"/><circle cx="15" cy="9" r="1.5" fill="currentColor"/></svg>';
            default: // star
                $d = 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z'; break;
        }
        return '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" opacity="' . $opacity . '"><path d="' . $d . '"/></svg>';
    }
}

if ( ! function_exists( 'ac_lire_svg_importe' ) ) {
    /**
     * Lit le contenu d'un fichier SVG importé via la médiathèque (attribut
     * customStarSvgUrl). Le fichier a déjà été nettoyé à l'upload
     * (AC_Avis_Uploads::nettoyer_svg_uploade()) ; on relit quand même via
     * wp_kses() dans ac_get_rating_svg() par sécurité en profondeur.
     *
     * Mis en cache statique par URL pour ne lire le fichier qu'une seule
     * fois même si la carte est répétée pour des dizaines d'avis.
     *
     * @param string $url URL du fichier SVG (médiathèque).
     * @return string Contenu brut du fichier, ou chaîne vide si introuvable.
     */
    function ac_lire_svg_importe( $url ) {
        static $cache = [];

        if ( isset( $cache[ $url ] ) ) {
            return $cache[ $url ];
        }

        $chemin = null;
        $post_id = attachment_url_to_postid( $url );
        if ( $post_id ) {
            $chemin = get_attached_file( $post_id );
        }

        if ( ! $chemin || ! file_exists( $chemin ) ) {
            $cache[ $url ] = '';
            return '';
        }

        $contenu = file_get_contents( $chemin );
        $cache[ $url ] = false !== $contenu ? $contenu : '';

        return $cache[ $url ];
    }
}

if ( ! function_exists( 'ac_enqueue_custom_font_face' ) ) {
    /**
     * Émet une règle @font-face pour une police importée (fichier .woff2/
     * .woff/.ttf/.otf de la médiathèque), une seule fois par fichier même si
     * le bloc qui l'utilise est répété (ex: avis-title dans chaque carte).
     *
     * @param string $font_name Nom à utiliser dans font-family (choisi par l'utilisateur).
     * @param string $font_url  URL du fichier de police importé.
     */
    function ac_enqueue_custom_font_face( $font_name, $font_url ) {
        static $deja_affiches = [];

        if ( empty( $font_name ) || empty( $font_url ) || isset( $deja_affiches[ $font_url ] ) ) {
            return;
        }
        $deja_affiches[ $font_url ] = true;

        $formats = [
            'woff2' => 'woff2',
            'woff'  => 'woff',
            'ttf'   => 'truetype',
            'otf'   => 'opentype',
        ];
        $extension = strtolower( pathinfo( wp_parse_url( $font_url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );

        if ( ! isset( $formats[ $extension ] ) ) {
            return;
        }

        printf(
            '<style>@font-face{font-family:"%s";src:url(%s) format("%s");font-display:swap;}</style>',
            esc_attr( $font_name ),
            esc_url( $font_url ),
            esc_attr( $formats[ $extension ] )
        );
    }
}

// ══════════════════════════════════════════════
// 1. EXTRACTION DES ATTRIBUTS
// ══════════════════════════════════════════════

$nombre_avis     = isset( $attributes['numberOfPosts']      ) ? intval( $attributes['numberOfPosts'] )      : 6;
$categories      = isset( $attributes['categorySelected']   ) ? (array) $attributes['categorySelected']    : [];
$order_by        = isset( $attributes['orderBy']            ) ? sanitize_key( $attributes['orderBy'] )      : 'date';
$note_min        = isset( $attributes['minRating']          ) ? intval( $attributes['minRating'] )          : 1;
$layout          = isset( $attributes['layout']             ) ? sanitize_key( $attributes['layout'] )       : 'grid';
$colonnes        = isset( $attributes['columns']            ) ? intval( $attributes['columns'] )            : 3;
$content_align   = isset( $attributes['contentAlign']       ) ? sanitize_key( $attributes['contentAlign'] ) : 'left';
$enable_pagination = isset( $attributes['enablePagination']  ) ? (bool) $attributes['enablePagination']      : false;

// Page courante : lue depuis le paramètre d'URL dédié ?avis_page=N (pas le
// "paged" natif de WordPress, pour ne pas entrer en conflit avec la pagination
// propre à la page/archive sur laquelle ce bloc est éventuellement inséré).
$page_courante = 1;
if ( $enable_pagination && isset( $_GET['avis_page'] ) ) {
    $page_courante = max( 1, intval( $_GET['avis_page'] ) );
}

// Carousel
$show_arrows     = isset( $attributes['showArrows']         ) ? (bool) $attributes['showArrows']            : true;
$show_dots       = isset( $attributes['showDots']           ) ? (bool) $attributes['showDots']             : true;
$autoplay        = isset( $attributes['autoplay']           ) ? (bool) $attributes['autoplay']              : false;
$autoplay_cont   = isset( $attributes['autoplayContinuous'] ) ? (bool) $attributes['autoplayContinuous']    : false;
$autoplay_speed  = isset( $attributes['autoplaySpeed']      ) ? intval( $attributes['autoplaySpeed'] )      : 5000;
$slides_per_view = isset( $attributes['slidesPerView']      ) ? intval( $attributes['slidesPerView'] )      : 1;

// Marquee
$marquee_speed   = isset( $attributes['marqueeSpeed']       ) ? intval( $attributes['marqueeSpeed'] )       : 30;
/* B11 : Nombre de rangées du marquee */
$marquee_rows    = isset( $attributes['marqueeRows']        ) ? max( 1, intval( $attributes['marqueeRows'] ) ) : 1;
$marquee_alternate = isset( $attributes['marqueeAlternateDirection'] ) ? (bool) $attributes['marqueeAlternateDirection'] : false;

// Badge
$badge_score    = isset( $attributes['badgeShowScore']   ) ? (bool) $attributes['badgeShowScore']   : true;
$badge_stars    = isset( $attributes['badgeShowStars']   ) ? (bool) $attributes['badgeShowStars']   : true;
$badge_count    = isset( $attributes['badgeShowCount']   ) ? (bool) $attributes['badgeShowCount']   : true;
/* B7 : Avatars dans le badge */
$badge_avatars  = isset( $attributes['badgeShowAvatars'] ) ? (bool) $attributes['badgeShowAvatars'] : true;
/* B6 : Style visuel du badge */
$badge_style    = isset( $attributes['badgeStyle']       ) ? sanitize_key( $attributes['badgeStyle'] ) : 'badge-google';

// Icône de notation et couleur (utilisées dans le bloc badge ET dans les cartes)
$rating_icon     = isset( $attributes['ratingIcon'] )     ? sanitize_key( $attributes['ratingIcon'] )      : 'star';
$custom_star_svg = isset( $attributes['customStarSvg'] )  ? $attributes['customStarSvg']                   : '';
$star_color      = isset( $attributes['starColor'] )      ? sanitize_hex_color( $attributes['starColor'] ) : '#fbbf24';


// ══════════════════════════════════════════════
// 2. CONSTRUCTION DE LA WP_QUERY
// ══════════════════════════════════════════════

$args = [
    'post_type'      => 'avis_client',
    'posts_per_page' => $nombre_avis,
    'post_status'    => 'publish',
    'paged'          => $page_courante,
];

// Tri
switch ( $order_by ) {
    case 'rating':
        $args['meta_key'] = '_ac_note';
        $args['orderby']  = 'meta_value_num';
        $args['order']    = 'DESC';
        break;
    case 'random':
        $args['orderby'] = 'rand';
        break;
    default: // date
        $args['orderby'] = 'date';
        $args['order']   = 'DESC';
}

// Filtre par catégorie
if ( ! empty( $categories ) ) {
    $args['tax_query'] = [[
        'taxonomy' => 'categorie_avis',
        'field'    => 'term_id',
        'terms'    => array_map( 'intval', $categories ),
    ]];
}

// Filtre par note minimale
if ( $note_min > 1 ) {
    $args['meta_query'] = [[
        'key'     => '_ac_note',
        'value'   => $note_min,
        'compare' => '>=',
        'type'    => 'NUMERIC',
    ]];
}

$requete = new WP_Query( $args );

if ( ! $requete->have_posts() ) {
    echo '<p class="ac-aucun-avis">' . esc_html__( 'Aucun avis client ne correspond à vos critères.', 'avis-clients' ) . '</p>';
    return;
}

// ══════════════════════════════════════════════
// 3. COLLECTE DES DONNÉES (posts + agrégat SEO)
// ══════════════════════════════════════════════

$posts_ids = [];
$aggregate = [ 'total' => 0, 'count' => 0, 'avatars' => [], 'reviews' => [] ];

while ( $requete->have_posts() ) {
    $requete->the_post();
    $pid  = get_the_ID();
    $note = intval( get_post_meta( $pid, '_ac_note', true ) );

    $posts_ids[]              = $pid;
    $aggregate['total']      += $note;
    $aggregate['count']++;

    // Données pour le SEO JSON-LD
    $aggregate['reviews'][] = [
        'author'      => get_post_meta( $pid, '_ac_nom_client', true ) ?: 'Anonyme',
        'date'        => get_post_meta( $pid, '_ac_date_avis', true ) ?: get_the_date( 'Y-m-d' ),
        'rating'      => $note,
        'description' => wp_strip_all_tags( get_the_content() )
    ];

    // Collecte jusqu'à 5 avatars pour les badges style "social proof"
    if ( count( $aggregate['avatars'] ) < 5 && has_post_thumbnail() ) {
        $aggregate['avatars'][] = get_the_post_thumbnail_url( $pid, 'thumbnail' );
    }
}
wp_reset_postdata();

$average_rating = $aggregate['count'] > 0
    ? round( $aggregate['total'] / $aggregate['count'], 1 )
    : 0;

// ══════════════════════════════════════════════
// 4. RENDU DE LA GRILLE / CAROUSEL
// ══════════════════════════════════════════════

$is_badge_layout = ( $layout === 'badge' );
$template_block  = null;

if ( ! $is_badge_layout ) {
    foreach ( $block->inner_blocks as $inner ) {
        if ( $inner->name === 'ac/avis-template' ) {
            $template_block = $inner;
            break;
        }
    }
}



/**
 * Fonction locale qui rend une carte (un post) via le bloc template.
 * Si le template_block n'existe pas (par ex. ancienne version du bloc non sauvegardée, ou ServerSideRender dans l'éditeur),
 * on utilise une structure fallback, en lisant l'attribut previewTemplate si disponible.
 */
$render_card = function( $post_id ) use ( $template_block, $attributes, $layout ) {
    $fallback_inner = [
        [ 'blockName' => 'ac/avis-avatar',    'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ],
        [ 'blockName' => 'ac/avis-rating',    'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ],
        [ 'blockName' => 'ac/avis-title',     'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ],
        [ 'blockName' => 'ac/avis-content',   'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ],
        [ 'blockName' => 'ac/avis-signature', 'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ],
    ];

    $parsed_block = null;
    if ( $template_block ) {
        $parsed_block = $template_block->parsed_block;
    } elseif ( ! empty( $attributes['previewTemplate'] ) ) {
        $preview = trim( $attributes['previewTemplate'] );
        if ( strpos( $preview, '[' ) === 0 ) {
            // Le template de prévisualisation est un JSON complet du bloc parent (ac/avis-template)
            $decoded = json_decode( wp_unslash( $preview ), true );
            if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) && ! empty( $decoded ) ) {
                foreach ( $decoded as $blk ) {
                    if ( isset( $blk['blockName'] ) && $blk['blockName'] === 'ac/avis-template' ) {
                        $parsed_block = $blk;
                        break;
                    }
                }
            }
        } else {
            // Rétrocompatibilité (liste de noms séparés par des virgules)
            $names = explode( ',', $preview );
            $new_inner = [];
            foreach ( $names as $name ) {
                $new_inner[] = [ 'blockName' => $name, 'attrs' => [], 'innerBlocks' => [], 'innerHTML' => '', 'innerContent' => [] ];
            }
            $parsed_block = [
                'blockName'    => 'ac/avis-template',
                'attrs'        => [],
                'innerBlocks'  => $new_inner,
                'innerHTML'    => '',
                'innerContent' => array_fill(0, count($new_inner), null),
            ];
        }
    }

    if ( ! $parsed_block ) {
        $parsed_block = [
            'blockName'    => 'ac/avis-template',
            'attrs'        => [],
            'innerBlocks'  => [],
            'innerHTML'    => '',
            'innerContent' => [],
        ];
    }

    $context = [
        'ac/postId'          => $post_id,
        'ac/layout'          => $layout,
    ];

    $html = ( new WP_Block(
        $parsed_block,
        $context
    ) )->render();
    

    return $html;
};

// ══════════════════════════════════════════════
// 5. CONSTRUCTION DU WRAPPER PRINCIPAL
// ══════════════════════════════════════════════

// wp_unique_id() (WP 5.9+) garantit un identifiant unique dans la requête en
// cours (compteur incrémental), contrairement à uniqid()/md5() qui peut
// théoriquement produire deux valeurs identiques si deux blocs se rendent
// à la même microseconde sur la même page.
$unique_id       = wp_unique_id( 'ac-q-' );
$card_style      = isset( $attributes['cardStyle'] ) ? sanitize_key( $attributes['cardStyle'] ) : 'grid';

/* Application des classes : on garde ac-layout-{layout} ET on ajoute ac-layout-{card_style} */
$active_layout   = $is_badge_layout ? 'badge' : $layout;
$wrapper_classes = 'ac-conteneur-avis ac-layout-' . esc_attr( $active_layout ) . ' ' . $unique_id;

if ( ! $is_badge_layout && $layout !== $card_style ) {
    if ( ! in_array( $card_style, ['grid', 'masonry', 'carousel', 'slider', 'marquee'] ) ) {
        $wrapper_classes .= ' ac-layout-' . esc_attr( $card_style );
    }
}

if ( $marquee_rows > 1 ) {
    $wrapper_classes .= ' ac-marquee-rows-' . $marquee_rows;
}

/* B6 : Classe de style du badge */
if ( $is_badge_layout ) {
    $wrapper_classes .= ' ac-badge-style-' . esc_attr( $badge_style );
}

/* Arrondi du conteneur + espacement entre les avis : appliqués via une
 * règle CSS scopée à cette instance (comme avis-form) avec !important. Le
 * panneau natif "Bordure"/"Espacement des blocs" ne s'affichant/n'agissant
 * pas de façon fiable pour ce bloc dans certains environnements (vérifié :
 * le bloc ET le thème autorisent bien la fonctionnalité), ces réglages
 * custom garantissent un résultat quel que soit ce problème natif. */
$container_border_radius = isset( $attributes['containerBorderRadius'] ) ? intval( $attributes['containerBorderRadius'] ) : 0;
$cards_gap                = isset( $attributes['cardsGap'] ) ? intval( $attributes['cardsGap'] ) : 24;
$radius_gap_css = sprintf(
    '<style>.%1$s{border-radius:%2$dpx !important;gap:%3$dpx !important;column-gap:%3$dpx !important;}.%1$s .ac-carousel-track,.%1$s .ac-marquee-track{gap:%3$dpx !important;}.%1$s .ac-marquee-track:not(:last-child){margin-bottom:%3$dpx !important;}</style>',
    $unique_id,
    $container_border_radius,
    $cards_gap
);

if ( $content_align === 'center' ) {
    $wrapper_classes .= ' ac-align-center';
}
if ( in_array( $layout, [ 'grid', 'masonry' ], true ) ) {
    $wrapper_classes .= ' ac-has-columns';
}

// Variables CSS pour colonnes et carousel (lues par style.css)
$inline_style = '--ac-cols:' . $colonnes . '; --ac-spv:' . $slides_per_view . ';';

// Chargement conditionnel du JS carousel
if ( $layout === 'carousel' && ! is_admin() ) {
    wp_enqueue_script(
        'ac-bloc-avis-view',
        plugins_url( '../../assets/js/view.js', __FILE__ ),
        [],
        filemtime( dirname( dirname( __DIR__ ) ) . '/assets/js/view.js' ),
        true
    );
}

// Chargement conditionnel des styles
wp_enqueue_style(
    'ac-bloc-avis-style-global',
    plugins_url( '../../assets/css/style.css', __FILE__ ),
    [],
    filemtime( dirname( dirname( __DIR__ ) ) . '/assets/css/style.css' )
);

// Attributs du wrapper FSE (intègre les supports natifs : spacing, color, etc.)
$wrapper_attrs = get_block_wrapper_attributes([
    'class' => $wrapper_classes,
    'style' => $inline_style,
]);

// Données data-* pour le JS du carousel
$carousel_attrs = '';
if ( $layout === 'carousel' ) {
    $carousel_attrs  = ' data-autoplay="'   . ( $autoplay ? 'true' : 'false' ) . '"';
    $carousel_attrs .= ' data-continuous="' . ( $autoplay_cont ? 'true' : 'false' ) . '"';
    $carousel_attrs .= ' data-speed="'      . esc_attr( $autoplay_speed ) . '"';
    $carousel_attrs .= ' data-slides-per-view="' . esc_attr( $slides_per_view ) . '"';
}

// ══════════════════════════════════════════════
// 6. GÉNÉRATION DU HTML SELON LE LAYOUT
// ══════════════════════════════════════════════

ob_start();

if ( $is_badge_layout ) {
    // ── Badge : affichage agrégé, pas de cartes individuelles ──
    $stars_svg = '';
    $avg_round = (int) round( $average_rating );
    for ( $i = 0; $i < $avg_round; $i++ )       { $stars_svg .= ac_get_rating_svg( $rating_icon, true,  $custom_star_svg ); }
    for ( $i = 0; $i < ( 5 - $avg_round ); $i++ ) { $stars_svg .= ac_get_rating_svg( $rating_icon, false, $custom_star_svg ); }

    echo '<div class="ac-badge-google-inner">';
    /* B7 : Stack d'avatars — affiché avant les étoiles si activé */
    if ( $badge_avatars && ! empty( $aggregate['avatars'] ) ) {
        echo '<div class="ac-badge-avatars-stack">';
        foreach ( array_slice( $aggregate['avatars'], 0, 5 ) as $avatar_url ) {
            echo '<img src="' . esc_url( $avatar_url ) . '" alt="" width="28" height="28" loading="lazy">';
        }
        echo '</div>';
    }
    if ( $badge_stars ) {
        echo '<span class="ac-badge-stars" style="color:' . esc_attr( $star_color ) . ';">' . $stars_svg . '</span>';
    }
    if ( $badge_score ) {
        echo '<span class="ac-badge-score">' . esc_html( $average_rating ) . '<small>/5</small></span>';
    }
    if ( $badge_count ) {
        echo '<span class="ac-badge-count">' . sprintf( esc_html__( '%d avis', 'avis-clients' ), $aggregate['count'] ) . '</span>';
    }
    echo '</div>';

} elseif ( $layout === 'carousel' ) {
    // ── Carousel : container > viewport > track > cartes ──
    echo '<div class="ac-carousel-container">';
    echo '<div class="ac-carousel-viewport">';
    echo '<div class="ac-carousel-track">';

    foreach ( $posts_ids as $pid ) {
        echo $render_card( $pid );
    }

    echo '</div>'; // fin .ac-carousel-track
    echo '</div>'; // fin .ac-carousel-viewport

    // Flèches de navigation (absolues par rapport au container)
    if ( $show_arrows ) {
        echo '<button class="ac-carousel-prev" aria-label="' . esc_attr__( 'Précédent', 'avis-clients' ) . '">';
        echo '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6z"/></svg>';
        echo '</button>';
        echo '<button class="ac-carousel-next" aria-label="' . esc_attr__( 'Suivant', 'avis-clients' ) . '">';
        echo '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/></svg>';
        echo '</button>';
    }
    
    echo '</div>'; // fin .ac-carousel-container

    // Points de pagination (sous le carousel)
    if ( $show_dots && ! empty( $posts_ids ) ) {
        echo '<div class="ac-carousel-dots">';
        foreach ( $posts_ids as $i => $pid ) {
            $active_class = $i === 0 ? ' ac-dot-active' : '';
            echo '<button class="ac-dot' . $active_class . '" data-index="' . $i . '" aria-label="' . sprintf( esc_attr__( 'Avis %d', 'avis-clients' ), $i + 1 ) . '"></button>';
        }
        echo '</div>';
    }

} elseif ( $layout === 'marquee' ) {
    // ── Marquee : piste(s) qui défile(nt) en boucle infinie ──
    // B11 : Si plusieurs rangées, on génère N tracks avec des délais décalés
    for ( $row = 0; $row < $marquee_rows; $row++ ) {
        /* Délai de départ décalé pour que les rangées ne soient pas synchronisées */
        $row_delay = ( $row * ( $marquee_speed / $marquee_rows ) );
        /* Sens alterné : une rangée sur deux joue l'animation à l'envers
         * (animation-direction: reverse sur .ac-marquee-reverse), ce qui
         * inverse visuellement le sens de défilement sans dupliquer le CSS. */
        $row_class = ( $marquee_alternate && $row % 2 === 1 ) ? ' ac-marquee-reverse' : '';
        echo '<div class="ac-marquee-track' . $row_class . '" style="--ac-marquee-duration:' . intval( $marquee_speed ) . 's; animation-delay:-' . round( $row_delay, 1 ) . 's;">';
        /* Première passe */
        foreach ( $posts_ids as $pid ) {
            echo $render_card( $pid );
        }
        /* Deuxième passe identique pour créer l'illusion de boucle infinie */
        foreach ( $posts_ids as $pid ) {
            echo $render_card( $pid );
        }
        echo '</div>';
    }

} else {
    // ── Grid / Masonry : boucle simple ──
    foreach ( $posts_ids as $pid ) {
        echo $render_card( $pid );
    }

    // Pagination "Page suivante / précédente" — n'a de sens que pour un
    // affichage en grille/liste (le carousel/marquee ont leur propre
    // navigation, le badge n'affiche pas de cartes individuelles).
    if ( $enable_pagination && $requete->max_num_pages > 1 ) {
        echo '<nav class="ac-pagination" aria-label="' . esc_attr__( 'Navigation entre les pages d\'avis', 'avis-clients' ) . '">';

        if ( $page_courante > 1 ) {
            $url_precedent = add_query_arg( 'avis_page', $page_courante - 1 );
            echo '<a class="ac-pagination-link ac-pagination-prev" href="' . esc_url( $url_precedent ) . '">' . esc_html__( '← Précédent', 'avis-clients' ) . '</a>';
        }

        echo '<span class="ac-pagination-status">' . sprintf(
            /* translators: 1: page courante, 2: nombre total de pages */
            esc_html__( 'Page %1$d sur %2$d', 'avis-clients' ),
            $page_courante,
            (int) $requete->max_num_pages
        ) . '</span>';

        if ( $page_courante < $requete->max_num_pages ) {
            $url_suivant = add_query_arg( 'avis_page', $page_courante + 1 );
            echo '<a class="ac-pagination-link ac-pagination-next" href="' . esc_url( $url_suivant ) . '">' . esc_html__( 'Suivant →', 'avis-clients' ) . '</a>';
        }

        echo '</nav>';
    }
}

$contenu_html = ob_get_clean();

// ══════════════════════════════════════════════
// 7. SEO — SCHEMA.ORG JSON-LD (AggregateRating)
// Injecté de façon invisible pour Google,
// permet d'afficher les étoiles dans les SERP.
// ══════════════════════════════════════════════

$json_ld = '';
if ( $aggregate['count'] > 0 ) {
    // sanitize_text_field() : l'attribut vient d'un champ texte du bloc et ne doit
    // contenir ni balises ni saut de ligne avant d'être injecté dans le schema.
    $entity_name = ! empty( $attributes['schemaEntityName'] )
        ? sanitize_text_field( $attributes['schemaEntityName'] )
        : get_bloginfo( 'name' );

    // Type d'entité évaluée : LocalBusiness par défaut (avis locaux), mais
    // Product/Organization sont plus pertinents pour un site e-commerce ou
    // une marque sans établissement physique.
    $types_autorises = [ 'LocalBusiness', 'Product', 'Organization' ];
    $entity_type = isset( $attributes['schemaEntityType'] ) && in_array( $attributes['schemaEntityType'], $types_autorises, true )
        ? $attributes['schemaEntityType']
        : 'LocalBusiness';

    $schema = [
        '@context' => 'https://schema.org/',
        '@type'    => $entity_type,
        'name'     => $entity_name,
        'aggregateRating' => [
            '@type'       => 'AggregateRating',
            'ratingValue' => $average_rating,
            'reviewCount' => $aggregate['count'],
            'bestRating'  => 5,
            'worstRating' => 1
        ],
        'review' => []
    ];

    // Ajout des avis individuels s'il ne s'agit pas juste d'un badge
    if ( ! $is_badge_layout ) {
        foreach ( $aggregate['reviews'] as $rev ) {
            // strtotime() renvoie false si la date stockée n'est pas parsable :
            // dans ce cas on omet datePublished plutôt que d'émettre un schema invalide.
            $timestamp = strtotime( $rev['date'] );

            $review_schema = [
                '@type'         => 'Review',
                'author'        => [ '@type' => 'Person', 'name' => $rev['author'] ],
                'reviewRating'  => [ '@type' => 'Rating', 'ratingValue' => $rev['rating'], 'bestRating' => 5, 'worstRating' => 1 ],
                'reviewBody'    => $rev['description']
            ];

            if ( false !== $timestamp ) {
                $review_schema['datePublished'] = wp_date( 'Y-m-d', $timestamp ); // Format ISO 8601 exigé, timezone WP
            }

            $schema['review'][] = $review_schema;
        }
    } else {
        unset( $schema['review'] );
    }

    // JSON_HEX_TAG évite qu'une valeur contenant "</script>" (ex: nom d'entité personnalisé)
    // ne puisse casser hors de la balise <script> et injecter du HTML/JS arbitraire.
    $json_ld = '<script type="application/ld+json">'
        . wp_json_encode( $schema, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT )
        . '</script>';
}

// ══════════════════════════════════════════════
// 8. SORTIE FINALE
// ══════════════════════════════════════════════
echo sprintf(
    '%s<div %s%s>%s</div>%s',
    $radius_gap_css,
    $wrapper_attrs,
    $carousel_attrs,
    $contenu_html,
    $json_ld
);
