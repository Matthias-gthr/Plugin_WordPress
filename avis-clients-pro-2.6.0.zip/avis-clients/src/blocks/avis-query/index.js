/**
 * Bloc « Avis Query » — Éditeur Gutenberg
 *
 * Architecture robuste : utilise le composant InnerBlocks directement
 * et s'assure qu'il est TOUJOURS rendu dans l'arbre React, même s'il est caché
 * visuellement, pour éviter que Gutenberg ne plante.
 *
 * Vanilla JS — aucun build requis.
 */
(function () {
    'use strict';

    /* ── Imports depuis les globals WordPress ── */
    var el                = wp.element.createElement;
    var Fragment          = wp.element.Fragment;
    var __                = wp.i18n.__;
    var registerBlockType = wp.blocks.registerBlockType;
    var InnerBlocks       = wp.blockEditor.InnerBlocks;
    var ServerSideRender  = wp.serverSideRender;
    var useBlockProps     = wp.blockEditor.useBlockProps;
    var InspectorControls = wp.blockEditor.InspectorControls;
    var PanelBody         = wp.components.PanelBody;
    var RangeControl      = wp.components.RangeControl;
    var SelectControl     = wp.components.SelectControl;
    var ToggleControl     = wp.components.ToggleControl;
    var TextareaControl   = wp.components.TextareaControl;
    var TextControl       = wp.components.TextControl;
    var useSelect         = wp.data.useSelect;
    var BaseControl       = wp.components.BaseControl;
    var TabPanel          = wp.components.TabPanel;
    var PanelColorSettings= wp.blockEditor.PanelColorSettings;

    /* ══════════════════════════════════════════
       Layouts disponibles dans le sélecteur
       ══════════════════════════════════════════ */
    var LAYOUTS = [
        {
            value: 'grid',
            label: __('Grille', 'avis-clients'),
            icon: '▦',
            description: __('Mise en page en colonnes responsives', 'avis-clients'),
        },
        {
            value: 'masonry',
            label: __('Mosaïque', 'avis-clients'),
            icon: '▧',
            description: __('Briques de hauteurs variables', 'avis-clients'),
        },
        {
            value: 'carousel',
            label: __('Carrousel', 'avis-clients'),
            icon: '⟵',
            description: __('Diaporama avec navigation', 'avis-clients'),
        },
        {
            value: 'marquee',
            label: __('Défilement', 'avis-clients'),
            icon: '→',
            description: __('Défilement continu en boucle infinie', 'avis-clients'),
        },
        {
            value: 'badge',
            label: __('Badge', 'avis-clients'),
            icon: '🏆',
            description: __('Résumé agrégé de la note globale', 'avis-clients'),
        },
    ];

    /* ══════════════════════════════════════════
       Template inner blocks
       ══════════════════════════════════════════ */
    var DEFAULT_TEMPLATE = [
        ['ac/avis-template', {}, [
            ['ac/avis-avatar',    {}],
            ['ac/avis-rating',    {}],
            ['ac/avis-title',     {}],
            ['ac/avis-content',   {}],
            ['ac/avis-signature', {}],
        ]],
    ];

    /* ══════════════════════════════════════════
       Composant Edit
       ══════════════════════════════════════════ */
    function EditAvisQuery(props) {
        var attributes    = props.attributes;
        var setAttributes = props.setAttributes;
        var layout        = attributes.layout;

        /* ── Hook 1 : Chargement des catégories ── */
        var categories = useSelect(function (select) {
            var coreStore = select('core');
            if (!coreStore) return [];
            return coreStore.getEntityRecords('taxonomy', 'categorie_avis', {
                per_page: 100,
                orderby: 'name',
                order: 'asc',
            }) || [];
        }, []);

        /* ── Hook 2 : Props du wrapper ── */
        var blockProps = useBlockProps();

        /* Le layout "Badge" n'affiche qu'un résumé agrégé (score, étoiles,
         * avatars) : il ne lit jamais les blocs enfants (ac/avis-template
         * et sa carte). On les retire donc complètement quand on choisit
         * ce layout, pour ne pas garder des blocs inutilisés en base.
         * Si l'utilisateur repart vers un autre layout, le "template"
         * de l'InnerBlocks ci-dessous recrée automatiquement le modèle
         * de carte par défaut (comportement natif de WordPress). */
        function handleLayoutChange(newLayout) {
            if (newLayout === 'badge') {
                wp.data.dispatch('core/block-editor').replaceInnerBlocks(props.clientId, [], false);
            }
            setAttributes({ layout: newLayout });
        }

        /* ── Fonction pour formater les blocs pour le PHP ── */
        function formatBlocksForPHP(blocksArray) {
            if (!blocksArray || !blocksArray.length) return [];
            return blocksArray.map(function (b) {
                var inners = formatBlocksForPHP(b.innerBlocks);
                var content = [];
                for (var i = 0; i < inners.length; i++) {
                    content.push(null);
                }
                return {
                    blockName: b.name,
                    attrs: b.attributes || {},
                    innerBlocks: inners,
                    innerHTML: '',
                    innerContent: content
                };
            });
        }

        /* ── Hook 3 : Extraction de l'état en direct des inner blocks pour la prévisualisation ── */
        var previewTemplate = useSelect(function (select) {
            var blocks = select('core/block-editor').getBlocks(props.clientId);
            if (blocks && blocks.length > 0) {
                // On sérialise complètement l'état du bloc ac/avis-template (y compris SES PROPRES couleurs et bordures)
                return JSON.stringify(formatBlocksForPHP(blocks));
            }
            return '';
        }, [props.clientId]);

        /* ── Dérivations (pas des hooks) ── */
        var isCarousel = layout === 'carousel';
        var isMarquee  = layout === 'marquee';
        var isBadge    = layout === 'badge';
        var hasColumns = layout === 'grid' || layout === 'masonry';
        var hasCards   = !isBadge;

        /* ══════════════════════════════════════════
           PANNEAUX SIDEBAR (Étape 3)
           ══════════════════════════════════════════ */

        var panelQuery = el(
            PanelBody,
            { title: __('Requête & Filtres', 'avis-clients'), initialOpen: true },
            el(TextControl, {
                label: __('Sujet de l\'avis (SEO)', 'avis-clients'),
                help: __('Nom de l\'entreprise ou du produit évalué (pour Google).', 'avis-clients'),
                value: attributes.schemaEntityName,
                onChange: function (v) { setAttributes({ schemaEntityName: v }); },
            }),
            el(SelectControl, {
                label: __('Type d\'entité (Schema.org)', 'avis-clients'),
                help: __('LocalBusiness pour un commerce local, Product pour un produit e-commerce, Organization pour une marque sans établissement physique.', 'avis-clients'),
                value: attributes.schemaEntityType || 'LocalBusiness',
                options: [
                    { value: 'LocalBusiness', label: __('Établissement local', 'avis-clients') },
                    { value: 'Product',       label: __('Produit', 'avis-clients') },
                    { value: 'Organization',  label: __('Organisation / Marque', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ schemaEntityType: v }); },
            }),
            el(RangeControl, {
                label: __('Nombre d\'avis', 'avis-clients'),
                value: attributes.numberOfPosts,
                onChange: function (v) { setAttributes({ numberOfPosts: v }); },
                min: 1,
                max: 50,
            }),
            el(SelectControl, {
                label: __('Trier par', 'avis-clients'),
                value: attributes.orderBy,
                options: [
                    { value: 'date',   label: __('Date', 'avis-clients') },
                    { value: 'rating', label: __('Note', 'avis-clients') },
                    { value: 'random', label: __('Aléatoire', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ orderBy: v }); },
            }),
            el(RangeControl, {
                label: __('Note minimale', 'avis-clients'),
                value: attributes.minRating,
                onChange: function (v) { setAttributes({ minRating: v }); },
                min: 1,
                max: 5,
            }),
            categories && categories.length > 0 && el(
                'fieldset',
                { style: { border: 'none', margin: '8px 0 0', padding: 0 } },
                el('legend', { style: { fontSize: '11px', fontWeight: 500, textTransform: 'uppercase', marginBottom: '8px', color: '#1e1e1e' } },
                    __('Catégories', 'avis-clients')
                ),
                el(
                    'div',
                    { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
                    categories.map(function (cat) {
                        var selected = (attributes.categorySelected || []).indexOf(cat.id) !== -1;
                        return el(
                            'label',
                            { key: cat.id, style: { display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px' } },
                            el('input', {
                                type: 'checkbox',
                                checked: selected,
                                onChange: function (e) {
                                    var current = (attributes.categorySelected || []).slice();
                                    var updated = e.target.checked
                                        ? current.concat([cat.id])
                                        : current.filter(function (id) { return id !== cat.id; });
                                    setAttributes({ categorySelected: updated });
                                },
                            }),
                            cat.name
                        );
                    })
                )
            )
        );

        var panelLayout = el(
            PanelBody,
            { title: __('Mise en page', 'avis-clients'), initialOpen: false },
            el(SelectControl, {
                label: __('Type de disposition', 'avis-clients'),
                value: layout,
                options: LAYOUTS.map(function (l) {
                    return { value: l.value, label: l.icon + ' ' + l.label };
                }),
                onChange: handleLayoutChange,
            }),
            /* ── L1 : Variantes selon le layout ──
             * Seules les variantes qui ont réellement un style CSS dédié
             * sont proposées ici. Les autres (Compact, Mur, Mise en avant,
             * Avatars Grille, Briques, Minimaliste, Citation simple, Liseré
             * gras/coloré, Avis unique, Liste standard côté grille ; Slider
             * texte/Slab/Mayen côté carrousel ; Vertical côté marquee)
             * étaient sélectionnables mais ne changeaient strictement rien
             * à l'affichage (aucune règle CSS ne les ciblait) — retirées. */
            (layout === 'grid' || layout === 'masonry') && el(SelectControl, {
                label: __('Variante visuelle', 'avis-clients'),
                value: attributes.cardStyle,
                options: [
                    { value: 'grid', label: __('Standard', 'avis-clients') },
                    { value: 'quote-grid', label: __('Citation (Guillemets)', 'avis-clients') },
                    { value: 'screenshots', label: __('Captures d\'écran', 'avis-clients') },
                    { value: 'image-gallery', label: __('Galerie image', 'avis-clients') },
                    { value: 'avatars-pro', label: __('Avatars Pro', 'avis-clients') },
                    { value: 'hero-quotes', label: __('Hero Citation', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ cardStyle: v }); },
            }),
            hasColumns && el(RangeControl, {
                label: __('Colonnes', 'avis-clients'),
                value: attributes.columns,
                onChange: function (v) { setAttributes({ columns: v }); },
                min: 1,
                max: 5,
            }),
            hasCards && el(SelectControl, {
                label: __('Alignement', 'avis-clients'),
                value: attributes.contentAlign,
                options: [
                    { value: 'left',   label: __('Gauche', 'avis-clients') },
                    { value: 'center', label: __('Centré', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ contentAlign: v }); },
            }),
            hasColumns && el(ToggleControl, {
                label: __('Pagination', 'avis-clients'),
                checked: !! attributes.enablePagination,
                help: __('Ajoute une navigation "Page suivante / précédente" au-delà du nombre d\'avis affichés.', 'avis-clients'),
                onChange: function (v) { setAttributes({ enablePagination: v }); },
            }),
            /* Contrôles "de secours" : le panneau natif "Bordure" et le
             * réglage natif "Espacement des blocs" sont bien autorisés
             * (bloc + thème vérifiés) mais n'apparaissent/n'agissent pas de
             * façon fiable sur ces blocs. Ces réglages appliquent le style
             * directement, donc fonctionnent quel que soit ce problème. */
            el(RangeControl, {
                label: __('Arrondi des coins du conteneur (px)', 'avis-clients'),
                value: attributes.containerBorderRadius,
                onChange: function (v) { setAttributes({ containerBorderRadius: v }); },
                min: 0,
                max: 60,
            }),
            hasCards && el(RangeControl, {
                label: __('Espacement entre les avis (px)', 'avis-clients'),
                value: attributes.cardsGap,
                onChange: function (v) { setAttributes({ cardsGap: v }); },
                min: 0,
                max: 80,
            }),
            isCarousel && el(RangeControl, {
                label: __('Avis visibles', 'avis-clients'),
                value: attributes.slidesPerView,
                onChange: function (v) { setAttributes({ slidesPerView: v }); },
                min: 1,
                max: 4,
            }),
            isCarousel && el(ToggleControl, {
                label: __('Flèches', 'avis-clients'),
                checked: attributes.showArrows,
                onChange: function (v) { setAttributes({ showArrows: v }); },
            }),
            isCarousel && el(ToggleControl, {
                label: __('Points de navigation', 'avis-clients'),
                checked: attributes.showDots,
                onChange: function (v) { setAttributes({ showDots: v }); },
            }),
            isCarousel && el(ToggleControl, {
                label: __('Lecture automatique', 'avis-clients'),
                checked: attributes.autoplay,
                onChange: function (v) { setAttributes({ autoplay: v }); },
            }),
            isCarousel && attributes.autoplay && el(RangeControl, {
                label: __('Délai (ms)', 'avis-clients'),
                value: attributes.autoplaySpeed,
                onChange: function (v) { setAttributes({ autoplaySpeed: v }); },
                min: 1000,
                max: 10000,
                step: 500,
            }),
            isMarquee && el(RangeControl, {
                label: __('Vitesse (secondes)', 'avis-clients'),
                value: attributes.marqueeSpeed,
                onChange: function (v) { setAttributes({ marqueeSpeed: v }); },
                min: 5,
                max: 120,
            }),
            /* B11 : Nombre de rangées du marquee */
            isMarquee && el(RangeControl, {
                label: __('Rangées', 'avis-clients'),
                value: attributes.marqueeRows,
                onChange: function (v) { setAttributes({ marqueeRows: v }); },
                min: 1,
                max: 4,
                help: __('Empile plusieurs lignes de défilement.', 'avis-clients'),
            }),
            isMarquee && attributes.marqueeRows > 1 && el(ToggleControl, {
                label: __('Sens alterné', 'avis-clients'),
                checked: !! attributes.marqueeAlternateDirection,
                onChange: function (v) { setAttributes({ marqueeAlternateDirection: v }); },
                help: __('Une rangée sur deux défile dans le sens opposé.', 'avis-clients'),
            }),
            /* B6 : Style visuel du badge */
            isBadge && el(SelectControl, {
                label: __('Style du badge', 'avis-clients'),
                value: attributes.badgeStyle,
                options: [
                    { value: 'badge-google', label: __('Google (horizontal)', 'avis-clients') },
                    { value: 'badge-inline', label: __('Inline (compact)', 'avis-clients') },
                    { value: 'badge-card',   label: __('Carte (vertical)', 'avis-clients') },
                    { value: 'badge-minimal',label: __('Minimal (texte seul)', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ badgeStyle: v }); },
            }),
            isBadge && el(ToggleControl, {
                label: __('Afficher la note', 'avis-clients'),
                checked: attributes.badgeShowScore,
                onChange: function (v) { setAttributes({ badgeShowScore: v }); },
            }),
            isBadge && el(ToggleControl, {
                label: __('Afficher les étoiles', 'avis-clients'),
                checked: attributes.badgeShowStars,
                onChange: function (v) { setAttributes({ badgeShowStars: v }); },
            }),
            isBadge && el(ToggleControl, {
                label: __('Afficher le nombre d\'avis', 'avis-clients'),
                checked: attributes.badgeShowCount,
                onChange: function (v) { setAttributes({ badgeShowCount: v }); },
            }),
            /* B7 : Stack d'avatars dans le badge */
            isBadge && el(ToggleControl, {
                label: __('Afficher les avatars clients', 'avis-clients'),
                checked: attributes.badgeShowAvatars,
                onChange: function (v) { setAttributes({ badgeShowAvatars: v }); },
                help: __('Empile les photos des clients pour renforcer la preuve sociale.', 'avis-clients'),
            }),
            /* Icône des étoiles du badge (jusqu'ici réglable uniquement via
             * l'attribut, sans aucun contrôle dans la sidebar). */
            isBadge && el(SelectControl, {
                label: __('Icône', 'avis-clients'),
                value: attributes.ratingIcon,
                options: [
                    { value: 'star',    label: '★ ' + __('Étoile', 'avis-clients') },
                    { value: 'heart',   label: '♥ ' + __('Cœur', 'avis-clients') },
                    { value: 'thumb',   label: '👍 ' + __('Pouce', 'avis-clients') },
                    { value: 'fire',    label: '🔥 ' + __('Feu', 'avis-clients') },
                    { value: 'check',   label: '✓ ' + __('Check', 'avis-clients') },
                    { value: 'diamond', label: '◆ ' + __('Diamant', 'avis-clients') },
                    { value: 'crown',   label: '♛ ' + __('Couronne', 'avis-clients') },
                    { value: 'smile',   label: '😊 ' + __('Sourire', 'avis-clients') },
                    { value: 'custom',  label: '✏️ ' + __('Personnalisé (SVG)', 'avis-clients') },
                ],
                onChange: function (v) { setAttributes({ ratingIcon: v }); },
            }),
            isBadge && attributes.ratingIcon === 'custom' && el(TextareaControl, {
                label: __('Code SVG personnalisé', 'avis-clients'),
                value: attributes.customStarSvg,
                rows: 4,
                help: __('Collez ici votre balise <svg>…</svg>.', 'avis-clients'),
                onChange: function (v) { setAttributes({ customStarSvg: v }); },
            })
        );

        /* Couleur des étoiles du badge — composant natif WordPress. */
        var panelBadgeColor = isBadge && el(
            PanelColorSettings,
            {
                title: __('Couleur des étoiles', 'avis-clients'),
                initialOpen: false,
                colorSettings: [
                    {
                        value: attributes.starColor,
                        onChange: function (v) { setAttributes({ starColor: v || '#fbbf24' }); },
                        label: __('Étoiles', 'avis-clients'),
                    },
                ],
            }
        );

        /* ══════════════════════════════════════════
           RENDU FINAL
           ══════════════════════════════════════════ */
        return el(
            Fragment,
            null,
            el(InspectorControls, null, panelQuery, panelLayout, panelBadgeColor),
            el(
                'div',
                blockProps,

                /* ── SÉLECTEUR DE LAYOUT (si aucun layout choisi) ── */
                !layout ? el(
                    'div',
                    null,
                    el('style', null, `
                        .ac-layout-picker { background:#f9f9f9; border:1px solid #e0e0e0; border-radius:12px; padding:2em; max-width:560px; margin:1em auto; }
                        .ac-layout-picker-header { text-align:center; margin-bottom:1.5em; }
                        .ac-layout-picker-icon-main { font-size:2.5em; display:block; margin-bottom:.25em; }
                        .ac-layout-picker-header h3 { font-size:1.1em; font-weight:600; margin:0 0 .5em; }
                        .ac-layout-picker-header p { color:#666; font-size:.9em; margin:0; }
                        .ac-layout-picker-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:.75em; }
                        .ac-layout-picker-btn { display:flex; flex-direction:column; align-items:center; gap:.4em; padding:1.25em .75em; background:#fff; border:1.5px solid #e0e0e0; border-radius:10px; cursor:pointer; transition:all .2s; text-align:center; width:100%; box-sizing: border-box; }
                        .ac-layout-picker-btn:hover { border-color:#007cba; background:#f0f8ff; transform:translateY(-2px); box-shadow:0 4px 12px rgba(0,124,186,.12); }
                        .ac-layout-picker-btn-icon { font-size:1.6em; }
                        .ac-layout-picker-btn-label { font-weight:600; font-size:.85em; margin-top:.5em; }
                        .ac-layout-picker-btn-desc { font-size:.75em; color:#777; line-height:1.3; }
                    `),
                    el(
                        'div',
                        { className: 'ac-layout-picker' },
                        el('div', { className: 'ac-layout-picker-header' },
                            el('span', { className: 'ac-layout-picker-icon-main' }, '💬'),
                            el('h3', {}, __('Choisir un type de mise en page', 'avis-clients')),
                            el('p', {}, __('Sélectionnez comment vos avis clients seront présentés.', 'avis-clients'))
                        ),
                        el('div', { className: 'ac-layout-picker-grid' },
                            LAYOUTS.map(function (l) {
                                return el('button', {
                                    key: l.value,
                                    className: 'ac-layout-picker-btn',
                                    type: 'button',
                                    onClick: function () { handleLayoutChange(l.value); },
                                },
                                el('span', { className: 'ac-layout-picker-btn-icon' }, l.icon),
                                el('span', { className: 'ac-layout-picker-btn-label' }, l.label),
                                el('span', { className: 'ac-layout-picker-btn-desc' }, l.description));
                            })
                        )
                    )
                ) : el(ServerSideRender, {
                    block: 'ac/avis-query',
                    attributes: Object.assign({}, attributes, { previewTemplate: previewTemplate })
                }),

                /* ── INNER BLOCKS (Template de carte caché) ──
                   Rendu invisible pour tous les layouts à cartes, afin de
                   permettre de sélectionner les composants dans la vue en
                   liste et modifier leurs réglages. Absent du tout en mode
                   Badge : ce layout n'affiche qu'un résumé agrégé et ne lit
                   jamais ces blocs enfants (voir handleLayoutChange, qui les
                   supprime déjà à la sélection de ce layout). Ne pas monter
                   <InnerBlocks> ici évite aussi que WordPress ne recrée le
                   modèle par défaut pendant qu'il est masqué. */
                hasCards && el(
                    'div',
                    { style: { display: 'none' } },
                    el(InnerBlocks, {
                        allowedBlocks: ['ac/avis-template'],
                        template: DEFAULT_TEMPLATE,
                        templateLock: 'all'
                    })
                )
            )
        );
    }

    /* ══════════════════════════════════════════
       Enregistrement du bloc
       ══════════════════════════════════════════ */
    registerBlockType('ac/avis-query', {
        edit: EditAvisQuery,
        save: function () {
            return el(InnerBlocks.Content, null);
        },
    });



})();
