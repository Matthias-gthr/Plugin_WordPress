document.addEventListener('DOMContentLoaded', function() {
    var forms = document.querySelectorAll('.ac-avis-form');
    
    forms.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            var btn = form.querySelector('.ac-submit-btn');
            var btnText = btn.querySelector('.ac-btn-text');
            var spinner = btn.querySelector('.ac-spinner');
            var successMsg = form.querySelector('.ac-success-msg');
            var errorMsg = form.querySelector('.ac-error-msg');
            
            // Honeypot check
            var honeypot = form.querySelector('input[name="ac_website"]').value;
            if (honeypot !== '') {
                // Silently reject bots
                return;
            }
            
            // FormData capture aussi le champ fichier (ac_photo) : on l'envoie
            // tel quel en multipart, pas en JSON, sinon la photo serait perdue.
            var formData = new FormData(form);

            // UI state
            btn.disabled = true;
            spinner.style.display = 'inline-block';
            errorMsg.style.display = 'none';
            successMsg.style.display = 'none';

            // Configuration
            var apiUrl = form.getAttribute('data-api-url');

            fetch(apiUrl, {
                method: 'POST',
                body: formData
            })
            .then(function(response) {
                return response.json().then(function(json) {
                    if (!response.ok) {
                        throw new Error(json.message || 'Une erreur est survenue.');
                    }
                    return json;
                });
            })
            .then(function(result) {
                successMsg.style.display = 'block';
                form.reset();
            })
            .catch(function(error) {
                errorMsg.textContent = error.message;
                errorMsg.style.display = 'block';
            })
            .finally(function() {
                btn.disabled = false;
                spinner.style.display = 'none';
            });
        });
    });
});
