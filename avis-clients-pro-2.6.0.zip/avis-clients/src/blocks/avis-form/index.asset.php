<?php
/* Dépendances du script éditeur du bloc ac/avis-form.
 * Version préfixée pour forcer le cache-busting. */
return array(
    'dependencies' => array(
        'wp-element',
        'wp-blocks',
        'wp-i18n',
        'wp-block-editor',
        'wp-components',
        'wp-server-side-render',
    ),
    'version' => '2.4.0.' . filemtime( __DIR__ . '/index.js' ),
);
