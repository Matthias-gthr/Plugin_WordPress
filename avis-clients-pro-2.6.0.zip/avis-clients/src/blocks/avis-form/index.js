/**
 * Bloc Gutenberg : ac/avis-form
 */
(function () {
    'use strict';

    var el                = wp.element.createElement;
    var Fragment          = wp.element.Fragment;
    var __                = wp.i18n.__;
    var registerBlockType = wp.blocks.registerBlockType;
    var useBlockProps     = wp.blockEditor.useBlockProps;
    var InspectorControls = wp.blockEditor.InspectorControls;
    var PanelBody         = wp.components.PanelBody;
    var TextControl       = wp.components.TextControl;
    var RangeControl      = wp.components.RangeControl;
    var PanelColorSettings= wp.blockEditor.PanelColorSettings;
    var ServerSideRender  = wp.serverSideRender;

    registerBlockType('ac/avis-form', {
        edit: function (props) {
            var attributes    = props.attributes;
            var setAttributes = props.setAttributes;

            var blockProps = useBlockProps({
                className: 'ac-avis-form-preview'
            });

            return el(
                Fragment,
                null,
                el(
                    InspectorControls,
                    null,
                    el(
                        PanelBody,
                        { title: __('Réglages du formulaire', 'avis-clients'), initialOpen: true },
                        el(TextControl, {
                            label: __('Texte du bouton', 'avis-clients'),
                            value: attributes.submitText,
                            onChange: function(v) { setAttributes({ submitText: v }); }
                        }),
                        el(TextControl, {
                            label: __('Message de succès', 'avis-clients'),
                            value: attributes.successMessage,
                            onChange: function(v) { setAttributes({ successMessage: v }); }
                        })
                    ),
                    el(
                        PanelColorSettings,
                        {
                            title: __('Couleurs du formulaire', 'avis-clients'),
                            initialOpen: false,
                            colorSettings: [
                                { value: attributes.formBackground, onChange: function(v) { setAttributes({ formBackground: v }); }, label: __('Fond du formulaire', 'avis-clients') },
                                { value: attributes.textColor, onChange: function(v) { setAttributes({ textColor: v }); }, label: __('Texte et labels', 'avis-clients') },
                                { value: attributes.buttonColor, onChange: function(v) { setAttributes({ buttonColor: v }); }, label: __('Bouton', 'avis-clients') },
                                { value: attributes.buttonTextColor, onChange: function(v) { setAttributes({ buttonTextColor: v }); }, label: __('Texte du bouton', 'avis-clients') },
                                { value: attributes.starColor, onChange: function(v) { setAttributes({ starColor: v }); }, label: __('Étoiles actives', 'avis-clients') },
                                { value: attributes.inputBorderColor, onChange: function(v) { setAttributes({ inputBorderColor: v }); }, label: __('Bordure des champs', 'avis-clients') }
                            ]
                        }
                    ),
                    el(
                        PanelBody,
                        { title: __('Style (Bordures)', 'avis-clients'), initialOpen: false },
                        el(RangeControl, {
                            label: __('Arrondi (Bordures)', 'avis-clients'),
                            value: attributes.borderRadius,
                            onChange: function(v) { setAttributes({ borderRadius: v }); },
                            min: 0,
                            max: 50
                        })
                    )
                ),
                el(
                    'div',
                    blockProps,
                    el(ServerSideRender, {
                        block: 'ac/avis-form',
                        attributes: attributes
                    })
                )
            );
        },
        save: function () {
            return null; // Rendu côté serveur
        }
    });
})();
