<?php
/**
 * Rendu côté serveur du bloc ac/avis-form.
 *
 * @package Avis_Clients
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$submit_text = isset( $attributes['submitText'] )     ? sanitize_text_field( $attributes['submitText'] )     : 'Envoyer mon avis';
$success_msg = isset( $attributes['successMessage'] ) ? sanitize_text_field( $attributes['successMessage'] ) : 'Merci ! Votre avis a été soumis avec succès.';

// wp_unique_id() (WP 5.9+) : voir avis-query/render.php pour le détail.
// Important ici car $unique_id sert aussi aux attributs id/for des champs
// du formulaire — deux id identiques sur une même page casseraient
// l'association <label for="..."> quand le bloc apparaît plusieurs fois.
$unique_id          = wp_unique_id( 'ac-form-' );
$wrapper_attributes = get_block_wrapper_attributes( [ 'class' => 'ac-avis-form-wrapper ' . $unique_id ] );

// Récupération et sanitisation des attributs de style (couleurs hex uniquement)
$formBackground   = isset( $attributes['formBackground']   ) ? sanitize_hex_color( $attributes['formBackground']   ) : '';
$textColor        = isset( $attributes['textColor']        ) ? sanitize_hex_color( $attributes['textColor']        ) : '';
$buttonColor      = isset( $attributes['buttonColor']      ) ? sanitize_hex_color( $attributes['buttonColor']      ) : '';
$buttonTextColor  = isset( $attributes['buttonTextColor']  ) ? sanitize_hex_color( $attributes['buttonTextColor']  ) : '';
$starColor        = isset( $attributes['starColor']        ) ? sanitize_hex_color( $attributes['starColor']        ) : '';
$inputBorderColor = isset( $attributes['inputBorderColor'] ) ? sanitize_hex_color( $attributes['inputBorderColor'] ) : '';
$borderRadius     = isset( $attributes['borderRadius']     ) ? (int) $attributes['borderRadius']                    : 8;

// Styles dynamiques
$css = '';
if ( $formBackground || $textColor || $borderRadius !== 8 ) {
    $css .= ".$unique_id {";
    if ( $formBackground ) $css .= " background: $formBackground;";
    if ( $textColor ) $css .= " color: $textColor;";
    if ( $borderRadius !== 8 ) $css .= " border-radius: {$borderRadius}px;";
    $css .= " }\n";
}
if ( $textColor ) {
    $css .= ".$unique_id .ac-form-group label { color: $textColor; }\n";
}
if ( $inputBorderColor ) {
    $css .= ".$unique_id .ac-form-group input[type='text'], .$unique_id .ac-form-group textarea { border-color: $inputBorderColor; }\n";
}
if ( $buttonColor || $buttonTextColor ) {
    $css .= ".$unique_id .ac-submit-btn {";
    if ( $buttonColor ) $css .= " background: $buttonColor;";
    if ( $buttonTextColor ) $css .= " color: $buttonTextColor;";
    $css .= " }\n";
}
if ( $starColor ) {
    $css .= ".$unique_id .ac-rating-input label:hover, .$unique_id .ac-rating-input label:hover ~ label, .$unique_id .ac-rating-input input:checked ~ label { color: $starColor; }\n";
}

if ( $css ) {
    echo '<style>' . wp_strip_all_tags($css) . '</style>';
}

// URL de l'API REST
$api_url = rest_url('avis-clients/v1/submit');
?>
<div <?php echo $wrapper_attributes; ?>>
    <form class="ac-avis-form" data-api-url="<?php echo esc_url($api_url); ?>">
        
        <fieldset class="ac-form-group ac-form-fieldset">
            <legend class="ac-form-label"><?php esc_html_e('Note', 'avis-clients'); ?> <span class="required">*</span></legend>
            <div class="ac-rating-input">
                <?php for ($i = 5; $i >= 1; $i--) : ?>
                    <input type="radio" id="<?php echo esc_attr($unique_id); ?>-star-<?php echo (int) $i; ?>" name="ac_note" value="<?php echo (int) $i; ?>" required />
                    <label for="<?php echo esc_attr($unique_id); ?>-star-<?php echo (int) $i; ?>" title="<?php echo (int) $i; ?> étoiles">★</label>
                <?php endfor; ?>
            </div>
        </fieldset>

        <div class="ac-form-group">
            <label for="<?php echo esc_attr($unique_id); ?>-nom"><?php esc_html_e('Votre nom', 'avis-clients'); ?> <span class="required">*</span></label>
            <input type="text" id="<?php echo esc_attr($unique_id); ?>-nom" name="ac_nom" required />
        </div>

        <div class="ac-form-group">
            <label for="<?php echo esc_attr($unique_id); ?>-content"><?php esc_html_e('Votre avis', 'avis-clients'); ?> <span class="required">*</span></label>
            <textarea id="<?php echo esc_attr($unique_id); ?>-content" name="ac_content" rows="4" required></textarea>
        </div>

        <div class="ac-form-group">
            <label for="<?php echo esc_attr($unique_id); ?>-photo"><?php esc_html_e('Votre photo (facultatif)', 'avis-clients'); ?></label>
            <input type="file" id="<?php echo esc_attr($unique_id); ?>-photo" name="ac_photo" accept="image/png,image/jpeg,image/webp" />
            <p class="ac-form-help"><?php esc_html_e('JPG, PNG ou WEBP, 2 Mo maximum.', 'avis-clients'); ?></p>
        </div>

        <!-- Honeypot anti-spam (champ caché) -->
        <div class="ac-form-group" style="display:none !important;" aria-hidden="true">
            <label for="<?php echo esc_attr($unique_id); ?>-website"><?php esc_html_e('Ne remplissez pas ce champ', 'avis-clients'); ?></label>
            <input type="text" id="<?php echo esc_attr($unique_id); ?>-website" name="ac_website" tabindex="-1" autocomplete="off" />
        </div>

        <div class="ac-form-message ac-success-msg" style="display:none;"><?php echo esc_html($success_msg); ?></div>
        <div class="ac-form-message ac-error-msg" style="display:none;"></div>

        <button type="submit" class="ac-submit-btn">
            <span class="ac-btn-text"><?php echo esc_html($submit_text); ?></span>
            <span class="ac-spinner" style="display:none;">⏳</span>
        </button>
    </form>
</div>
