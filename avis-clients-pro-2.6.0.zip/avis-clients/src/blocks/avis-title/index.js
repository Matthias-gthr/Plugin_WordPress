/**
 * Bloc Gutenberg : ac/avis-title
 *
 * Affiche le titre de l'avis (post title) dans le contexte du template ac/avis-template.
 * Le rendu réel est délégué à render.php ; save() retourne null (bloc dynamique).
 *
 * Dépendances : wp-blocks, wp-block-editor, wp-components, wp-element, wp-i18n
 */

( function () {
	'use strict';

	/* --- Récupération des API WordPress depuis l'objet global --- */
	var registerBlockType  = wp.blocks.registerBlockType;
	var el                 = wp.element.createElement;
	var Fragment           = wp.element.Fragment;
	var __                 = wp.i18n.__;
	var useBlockProps      = wp.blockEditor.useBlockProps;
	var InspectorControls  = wp.blockEditor.InspectorControls;
	var PanelBody          = wp.components.PanelBody;
	var SelectControl      = wp.components.SelectControl;
	var TextControl        = wp.components.TextControl;
	var Button             = wp.components.Button;
	var MediaUpload        = wp.blockEditor.MediaUpload;
	var MediaUploadCheck   = wp.blockEditor.MediaUploadCheck;

	/* Contrôle de police partagé : "Police du thème" reste géré nativement
	 * par WordPress (support typography.fontFamily déclaré dans block.json,
	 * menu injecté automatiquement dans le panneau Typographie). Ici on
	 * ajoute deux façons de sortir de la liste du thème :
	 *   - taper le nom d'une police Google Fonts (chargée à la volée),
	 *   - importer un vrai fichier de police (.woff2/.woff/.ttf/.otf) via
	 *     la médiathèque, qui génère la règle @font-face nécessaire
	 *     (voir ac_enqueue_custom_font_face() dans avis-query/render.php).
	 * Les deux options sont exclusives : importer un fichier prend le pas
	 * sur le nom Google Fonts. */
	function renderFontControl( attributes, setAttributes ) {
		var hasFile = !! attributes.customFontUrl;
		return el( Fragment, null,
			el( TextControl, {
				label:    __( 'Police Google Font (nom exact)', 'avis-clients' ),
				value:    attributes.customFont,
				help:     hasFile
					? __( 'Désactivé : un fichier de police importé est actif.', 'avis-clients' )
					: __( 'Exemple: Montserrat, Roboto, Open Sans. Laissez vide pour utiliser la police du thème.', 'avis-clients' ),
				disabled: hasFile,
				onChange: function ( v ) { setAttributes( { customFont: v } ); },
			} ),
			el( MediaUploadCheck, null,
				el( MediaUpload, {
					onSelect: function ( media ) {
						setAttributes( {
							customFontUrl: media.url,
							customFont:    attributes.customFont || media.title || 'Police importée',
						} );
					},
					render: function ( obj ) {
						return el( Button, {
							variant: 'secondary',
							onClick: obj.open,
							style: { marginTop: '8px' },
						}, hasFile
							? __( 'Changer le fichier de police', 'avis-clients' )
							: __( 'Importer un fichier de police', 'avis-clients' )
						);
					},
				} )
			),
			hasFile && el( 'div', { style: { marginTop: '6px', fontSize: '12px' } },
				el( 'code', {}, attributes.customFontUrl.split( '/' ).pop() ),
				' — ',
				el( Button, {
					variant: 'link',
					isDestructive: true,
					onClick: function () { setAttributes( { customFontUrl: '' } ); },
				}, __( 'Retirer', 'avis-clients' ) )
			)
		);
	}

	/**
	 * Définition des options de niveau de titre (h1 à h6).
	 * La valeur est un entier pour correspondre à l'attribut "level" défini dans block.json.
	 */
	var niveauxTitre = [
		{ label: 'H1', value: 1 },
		{ label: 'H2', value: 2 },
		{ label: 'H3', value: 3 },
		{ label: 'H4', value: 4 },
		{ label: 'H5', value: 5 },
		{ label: 'H6', value: 6 },
	];

	/* --- Enregistrement du bloc --- */
	registerBlockType( 'ac/avis-title', {

		/**
		 * Fonction d'édition : affichage dans l'éditeur Gutenberg.
		 * Montre un placeholder visuel du titre et un contrôle de niveau dans la sidebar.
		 *
		 * @param {Object} props - Propriétés du bloc (attributes, setAttributes).
		 */
		edit: function ( props ) {
			var attributes    = props.attributes;
			var setAttributes = props.setAttributes;
			var level         = attributes.level;

			/* Propriétés du wrapper bloc (classe, data-attributes, style, etc.) */
			var blockProps = useBlockProps( {
				style: { display: 'block' },
			} );

			return el(
				Fragment,
				null,

				/* --- Panneau de configuration dans la sidebar de l'éditeur --- */
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{
							title: __( 'Réglages du titre', 'avis-clients' ),
							initialOpen: true,
						},
						el( SelectControl, {
							/* Sélecteur de niveau de balise (h1 à h6) */
							label:    __( 'Niveau de titre', 'avis-clients' ),
							value:    level,
							options:  niveauxTitre,
							onChange: function ( nouvelleValeur ) {
								/* Conversion en entier car SelectControl retourne une chaîne */
								setAttributes( { level: parseInt( nouvelleValeur, 10 ) } );
							},
						} ),
						renderFontControl( attributes, setAttributes )
					)
				),

				/* --- Aperçu dans l'éditeur : placeholder gris du titre --- */
				el(
					'div',
					blockProps,
					el(
						'p',
						{
							style: {
								color:      '#aaa',        // Couleur grise pour signaler un placeholder
								fontStyle:  'italic',
								margin:     0,
								fontSize:   '1.1em',
							},
						},
						__( 'Titre de l\'avis', 'avis-clients' )
					)
				)
			);
		},

		/**
		 * save() retourne null car ce bloc est dynamique :
		 * le rendu HTML est entièrement géré côté serveur dans render.php.
		 *
		 * @returns {null}
		 */
		save: function () {
			return null;
		},
	} );

} )();
