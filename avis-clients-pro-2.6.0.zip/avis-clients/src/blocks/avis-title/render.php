<?php
/**
 * Rendu côté serveur pour le bloc ac/avis-title.
 *
 * Ce fichier est appelé par WordPress lors du rendu du bloc.
 * Il récupère le titre du post associé via le contexte du bloc
 * et l'affiche dans la balise de titre appropriée (h1 à h6).
 *
 * Variables disponibles automatiquement injectées par WordPress :
 *   @var array    $attributes   Attributs du bloc (ex. level).
 *   @var string   $content      Contenu interne du bloc (non utilisé ici).
 *   @var WP_Block $block        Instance du bloc, donne accès au contexte.
 */

/* --- Récupération du postId depuis le contexte du bloc parent (ac/avis-template) --- */
$post_id = isset( $block->context['ac/postId'] ) ? (int) $block->context['ac/postId'] : 0;

/* Si aucun post n'est associé, on n'affiche rien pour éviter un rendu vide ou erroné */
if ( ! $post_id ) {
	return;
}

/* --- Récupération et validation du titre du post --- */
$titre = get_the_title( $post_id );

/* Si le post n'a pas de titre, on n'affiche rien */
if ( ! $titre ) {
	return;
}

/* --- Détermination du niveau de balise (h1 à h6, par défaut h4) --- */
$level = isset( $attributes['level'] ) ? (int) $attributes['level'] : 4;

/* Contrainte de sécurité : le niveau doit être compris entre 1 et 6 */
$level = max( 1, min( 6, $level ) );

/* Construction de la balise HTML dynamique, ex. "h4" */
$balise = 'h' . $level;

/* F3 : Gestion de la police personnalisée — soit un fichier importé
 * (customFontUrl, prioritaire, @font-face généré par ac_enqueue_custom_font_face()),
 * soit un nom Google Fonts chargé à la volée. Sans ça, la police du thème
 * (support natif typography.fontFamily) s'applique normalement. */
$custom_font     = isset( $attributes['customFont'] ) ? trim( $attributes['customFont'] ) : '';
$custom_font_url = isset( $attributes['customFontUrl'] ) ? esc_url_raw( $attributes['customFontUrl'] ) : '';
$google_fonts_html = '';
$custom_font_style = '';

if ( ! empty( $custom_font_url ) && ! empty( $custom_font ) ) {
	if ( function_exists( 'ac_enqueue_custom_font_face' ) ) {
		ac_enqueue_custom_font_face( $custom_font, $custom_font_url );
	}
	$custom_font_style = 'font-family: "' . esc_attr( $custom_font ) . '" !important;';
} elseif ( ! empty( $custom_font ) ) {
	$primary_font = trim( str_replace( ['"', "'"], '', explode( ',', $custom_font )[0] ) );
	$system_fonts = ['Arial', 'Helvetica', 'Verdana', 'Georgia', 'Times New Roman', 'sans-serif', 'serif', 'monospace', 'inherit', 'initial'];

	if ( strpos( $primary_font, 'var(' ) === false && ! in_array( $primary_font, $system_fonts ) ) {
		$fonts_url = 'https://fonts.googleapis.com/css2?family=' . urlencode( $primary_font ) . ':wght@400;500;600;700;800;900&display=swap';
		$google_fonts_html = '<link href="' . esc_url( $fonts_url ) . '" rel="stylesheet">';
		$custom_font_style = 'font-family: ' . esc_attr( $custom_font ) . ' !important;';
	}
}

/*
 * Construction des attributs du wrapper du bloc.
 * get_block_wrapper_attributes() ajoute automatiquement les classes et styles
 * générés par les supports du bloc (couleur, espacement, typographie…).
 * On y ajoute la classe CSS personnalisée du plugin.
 */
$wrapper_args = array( 'class' => 'ac-avis-titre' );
if ( ! empty( $custom_font_style ) ) {
	$wrapper_args['style'] = $custom_font_style;
}
$wrapper_attributes = get_block_wrapper_attributes( $wrapper_args );

/* --- Génération du HTML final --- */
echo $google_fonts_html . sprintf(
	'<%1$s %2$s>%3$s</%1$s>',
	$balise,                    // La balise dynamique (h1…h6), non échappée car construite en interne
	$wrapper_attributes,        // Les attributs du wrapper (sûrs, générés par WP)
	esc_html( $titre )          // Le titre échappé pour prévenir les injections XSS
);
