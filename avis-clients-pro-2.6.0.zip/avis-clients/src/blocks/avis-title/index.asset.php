<?php
/**
 * Fichier de dépendances généré automatiquement pour le bloc ac/avis-title.
 * La version est calculée dynamiquement via filemtime pour forcer le rechargement
 * du script dès que le fichier index.js est modifié (cache-busting).
 */
return array(
    'dependencies' => array(
        'wp-element',       // Fournit les fonctions React (createElement, etc.)
        'wp-blocks',        // API d'enregistrement des blocs
        'wp-i18n',          // Internationalisation (__(), _x(), etc.)
        'wp-block-editor',  // useBlockProps, InspectorControls, etc.
        'wp-components',    // Composants UI : SelectControl, PanelBody, etc.
    ),
    'version' => '2.1.2.' . filemtime( __DIR__ . '/index.js' ),
);
