<?php
/**
 * Rendu côté serveur pour le bloc ac/avis-content.
 *
 * Ce fichier est appelé par WordPress lors du rendu du bloc.
 * Il récupère le contenu (post_content) du post associé via le contexte du bloc,
 * applique le formatage WordPress standard (wpautop) et filtre le HTML autorisé
 * (wp_kses_post). Si l'option "Lire la suite" est activée, le contenu est tronqué
 * visuellement via CSS (line-clamp) et un bouton de dépliement est ajouté.
 *
 * Variables disponibles automatiquement injectées par WordPress :
 *   @var array    $attributes   Attributs du bloc (enableReadMore, readMoreLines).
 *   @var string   $content      Contenu interne du bloc (non utilisé ici).
 *   @var WP_Block $block        Instance du bloc, donne accès au contexte.
 */

/* --- Récupération du postId depuis le contexte du bloc parent (ac/avis-template) --- */
$post_id = isset( $block->context['ac/postId'] ) ? (int) $block->context['ac/postId'] : 0;

/* Si aucun post n'est associé, on n'affiche rien */
if ( ! $post_id ) {
	return;
}

/* --- Récupération du post pour accéder à post_content --- */
$post = get_post( $post_id );

/* Vérification que le post existe bien */
if ( ! $post ) {
	return;
}

/*
 * Récupération du contenu brut du post.
 * - wpautop() convertit les sauts de ligne en balises <p> (comportance WordPress standard).
 * - wp_kses_post() filtre le HTML pour n'autoriser que les balises sûres dans un contexte de post.
 */
$contenu = wp_kses_post( wpautop( $post->post_content ) );

/* Si le contenu est vide, on n'affiche rien */
if ( ! trim( $contenu ) ) {
	return;
}

/* --- Récupération des attributs de configuration du bloc --- */
$enable_read_more = ! empty( $attributes['enableReadMore'] );
$read_more_lines  = isset( $attributes['readMoreLines'] ) ? (int) $attributes['readMoreLines'] : 3;

/* Contrainte de sécurité : le nombre de lignes doit être entre 2 et 8 */
$read_more_lines = max( 2, min( 8, $read_more_lines ) );

/* B5 : Style custom du bouton "Lire la suite" :
 * Chaque propriété n'est injectée que si elle est définie par l'utilisateur. */
$btn_text_color   = isset( $attributes['readMoreTextColor']    ) ? sanitize_hex_color( $attributes['readMoreTextColor']    ) : '';
$btn_bg_color     = isset( $attributes['readMoreBgColor']      ) ? sanitize_hex_color( $attributes['readMoreBgColor']      ) : '';
$btn_border_color = isset( $attributes['readMoreBorderColor']  ) ? sanitize_hex_color( $attributes['readMoreBorderColor']  ) : '';
$btn_border_width = isset( $attributes['readMoreBorderWidth']  ) ? intval( $attributes['readMoreBorderWidth']  ) : 0;
$btn_border_radius= isset( $attributes['readMoreBorderRadius'] ) ? intval( $attributes['readMoreBorderRadius'] ) : 4;

/* F3 : Gestion de la police personnalisée — fichier importé (prioritaire,
 * @font-face généré par ac_enqueue_custom_font_face()) ou nom Google Fonts.
 * Sans ça, la police du thème (support natif typography.fontFamily) s'applique. */
$custom_font     = isset( $attributes['customFont'] ) ? trim( $attributes['customFont'] ) : '';
$custom_font_url = isset( $attributes['customFontUrl'] ) ? esc_url_raw( $attributes['customFontUrl'] ) : '';
$google_fonts_html = '';
$custom_font_style = '';

if ( ! empty( $custom_font_url ) && ! empty( $custom_font ) ) {
	if ( function_exists( 'ac_enqueue_custom_font_face' ) ) {
		ac_enqueue_custom_font_face( $custom_font, $custom_font_url );
	}
	$custom_font_style = 'font-family: "' . esc_attr( $custom_font ) . '" !important;';
} elseif ( ! empty( $custom_font ) ) {
	$primary_font = trim( str_replace( ['"', "'"], '', explode( ',', $custom_font )[0] ) );
	$system_fonts = ['Arial', 'Helvetica', 'Verdana', 'Georgia', 'Times New Roman', 'sans-serif', 'serif', 'monospace', 'inherit', 'initial'];

	if ( strpos( $primary_font, 'var(' ) === false && ! in_array( $primary_font, $system_fonts ) ) {
		$fonts_url = 'https://fonts.googleapis.com/css2?family=' . urlencode( $primary_font ) . ':wght@400;500;600;700&display=swap';
		$google_fonts_html = '<link href="' . esc_url( $fonts_url ) . '" rel="stylesheet">';
		$custom_font_style = 'font-family: ' . esc_attr( $custom_font ) . ' !important;';
	}
}

/* Construction du style inline du bouton uniquement si au moins un paramètre est défini */
$btn_style_parts = array_filter( [
    $btn_text_color   ? 'color:' . $btn_text_color . ';'                                                   : '',
    $btn_bg_color     ? 'background-color:' . $btn_bg_color . ';'                                          : '',
    $btn_border_width ? 'border:' . $btn_border_width . 'px solid ' . ( $btn_border_color ?: 'currentColor' ) . ';' : '',
    'border-radius:' . $btn_border_radius . 'px;',
] );
$btn_style = ! empty( $btn_style_parts ) ? ' style="' . esc_attr( implode( ' ', $btn_style_parts ) ) . '"' : '';

/*
 * Construction des classes CSS du wrapper principal.
 * La classe 'ac-read-more-enabled' est ajoutée conditionnellement
 * pour permettre au CSS du plugin d'appliquer la troncature via line-clamp.
 */
$classes_wrapper = 'ac-avis-texte-wrapper';
if ( $enable_read_more ) {
	$classes_wrapper .= ' ac-read-more-enabled';
}

/*
 * Construction des attributs du wrapper du bloc.
 * get_block_wrapper_attributes() ajoute automatiquement les classes et styles
 * générés par les supports du bloc (couleur, espacement, typographie…).
 */
$wrapper_args = array( 'class' => $classes_wrapper );
if ( ! empty( $custom_font_style ) ) {
	$wrapper_args['style'] = $custom_font_style;
}
$wrapper_attributes = get_block_wrapper_attributes( $wrapper_args );

/* --- Construction de la variable CSS inline pour le nombre de lignes (si "Lire la suite" actif) --- */
$style_inline = '';
if ( $enable_read_more ) {
	/*
	 * On passe le nombre de lignes en variable CSS custom pour que le CSS puisse
	 * utiliser -webkit-line-clamp: var(--ac-read-more-lines) sans JavaScript.
	 */
	$style_inline = sprintf(
		' style="--ac-read-more-lines: %d;"',
		$read_more_lines
	);
}

/* --- Génération du HTML final --- */
ob_start();
?>
<?php echo $google_fonts_html; // Tag link injecté si une Google Font personnalisée est demandée ?>
<div <?php echo $wrapper_attributes; // Les attributs du wrapper sont générés par WP, sûrs ?>>
	<?php if ( $enable_read_more ) : ?>
		<?php /* Zone de contenu tronqué : la classe ac-avis-texte est ciblée par le CSS du plugin */ ?>
		<div class="ac-avis-texte"<?php echo $style_inline; ?>>
			<?php echo $contenu; // Déjà passé par wp_kses_post(), sûr à afficher ?>
		</div>

		<?php /* Bouton pour déplier le texte complet, géré par le JS du plugin (ac-read-more.js)
		 * B5 : Le style inline est injecté si l'utilisateur a personnalisé le bouton. */ ?>
		<button
			class="ac-read-more-btn"
			aria-expanded="false"
			type="button"
			data-label-more="<?php esc_attr_e( 'Lire la suite', 'avis-clients' ); ?>"
			data-label-less="<?php esc_attr_e( 'Voir moins', 'avis-clients' ); ?>"
			<?php echo $btn_style; // Style inline du bouton, sûr car échappé via esc_attr() ?>
		>
			<?php esc_html_e( 'Lire la suite', 'avis-clients' ); ?>
		</button>
	<?php else : ?>
		<?php /* Affichage normal sans troncature */ ?>
		<div class="ac-avis-texte">
			<?php echo $contenu; // Déjà passé par wp_kses_post(), sûr à afficher ?>
		</div>
	<?php endif; ?>
</div>
<?php
echo ob_get_clean();
