<?php
/* Dépendances du script éditeur du bloc ac/avis-content.
 * Version préfixée pour forcer le cache-busting après ajout du customFont. */
return array(
    'dependencies' => array(
        'wp-element',
        'wp-blocks',
        'wp-i18n',
        'wp-block-editor',
        'wp-components',
    ),
    'version' => '2.1.2.' . filemtime( __DIR__ . '/index.js' ),
);
