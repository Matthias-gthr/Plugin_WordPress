/**
 * Bloc Gutenberg : ac/avis-content
 *
 * Affiche le corps du témoignage client dans le contexte du template ac/avis-template.
 * Le rendu réel est délégué à render.php ; save() retourne null (bloc dynamique).
 *
 * Ajout B5 : panneau "Style du bouton Lire la suite" conditionnel.
 * Dépendances : wp-blocks, wp-block-editor, wp-components, wp-element, wp-i18n
 */

( function () {
	'use strict';

	/* --- Récupération des API WordPress depuis l'objet global --- */
	var registerBlockType  = wp.blocks.registerBlockType;
	var el                 = wp.element.createElement;
	var Fragment           = wp.element.Fragment;
	var __                 = wp.i18n.__;
	var useBlockProps      = wp.blockEditor.useBlockProps;
	var InspectorControls  = wp.blockEditor.InspectorControls;
	var PanelBody          = wp.components.PanelBody;
	var ToggleControl      = wp.components.ToggleControl;
	var RangeControl       = wp.components.RangeControl;
	var TextControl        = wp.components.TextControl;
	var Button             = wp.components.Button;
	var MediaUpload        = wp.blockEditor.MediaUpload;
	var MediaUploadCheck   = wp.blockEditor.MediaUploadCheck;
	var PanelColorSettings = wp.blockEditor.PanelColorSettings;

	/* Contrôle de police partagé : voir avis-title/index.js pour le détail.
	 * "Police du thème" reste géré nativement par WordPress (support
	 * typography.fontFamily déclaré dans block.json) ; ici on ajoute le nom
	 * Google Fonts et l'import d'un vrai fichier de police, exclusifs entre eux. */
	function renderFontControl( attributes, setAttributes ) {
		var hasFile = !! attributes.customFontUrl;
		return el( Fragment, null,
			el( TextControl, {
				label:    __( 'Police Google Font (nom exact)', 'avis-clients' ),
				value:    attributes.customFont,
				help:     hasFile
					? __( 'Désactivé : un fichier de police importé est actif.', 'avis-clients' )
					: __( 'Exemple: Montserrat, Roboto, Open Sans. Laissez vide pour utiliser la police du thème.', 'avis-clients' ),
				disabled: hasFile,
				onChange: function ( v ) { setAttributes( { customFont: v } ); },
			} ),
			el( MediaUploadCheck, null,
				el( MediaUpload, {
					onSelect: function ( media ) {
						setAttributes( {
							customFontUrl: media.url,
							customFont:    attributes.customFont || media.title || 'Police importée',
						} );
					},
					render: function ( obj ) {
						return el( Button, {
							variant: 'secondary',
							onClick: obj.open,
							style: { marginTop: '8px' },
						}, hasFile
							? __( 'Changer le fichier de police', 'avis-clients' )
							: __( 'Importer un fichier de police', 'avis-clients' )
						);
					},
				} )
			),
			hasFile && el( 'div', { style: { marginTop: '6px', fontSize: '12px' } },
				el( 'code', {}, attributes.customFontUrl.split( '/' ).pop() ),
				' — ',
				el( Button, {
					variant: 'link',
					isDestructive: true,
					onClick: function () { setAttributes( { customFontUrl: '' } ); },
				}, __( 'Retirer', 'avis-clients' ) )
			)
		);
	}

	/* --- Enregistrement du bloc --- */
	registerBlockType( 'ac/avis-content', {

		edit: function ( props ) {
			var attributes      = props.attributes;
			var setAttributes   = props.setAttributes;
			var enableReadMore  = attributes.enableReadMore;
			var readMoreLines   = attributes.readMoreLines;

			var blockProps = useBlockProps( { style: { display: 'block' } } );

			/* ── Panneau "Réglages du texte" ── */
			var panelText = el(
				PanelBody,
				{ title: __( 'Réglages du texte', 'avis-clients' ), initialOpen: true },
				el( ToggleControl, {
					label:    __( 'Activer "Lire la suite"', 'avis-clients' ),
					checked:  enableReadMore,
					onChange: function ( v ) { setAttributes( { enableReadMore: v } ); },
				} ),
				enableReadMore && el( RangeControl, {
					label:    __( 'Lignes visibles', 'avis-clients' ),
					value:    readMoreLines,
					min:      2,
					max:      8,
					onChange: function ( v ) { setAttributes( { readMoreLines: v } ); },
				} ),
				renderFontControl( attributes, setAttributes )
			);

			/* ── Panneau B5 : Style du bouton "Lire la suite"
			 * Visible uniquement quand enableReadMore est activé. ── */
			var panelReadMoreStyle = enableReadMore && el(
				PanelBody,
				{ title: __( 'Style du bouton', 'avis-clients' ), initialOpen: false },

				/* Épaisseur de la bordure */
				el( RangeControl, {
					label:    __( 'Épaisseur de bordure (px)', 'avis-clients' ),
					value:    attributes.readMoreBorderWidth,
					min: 0, max: 5,
					onChange: function ( v ) { setAttributes( { readMoreBorderWidth: v } ); },
				} ),

				/* Arrondi des coins */
				el( RangeControl, {
					label:    __( 'Arrondi des coins (px)', 'avis-clients' ),
					value:    attributes.readMoreBorderRadius,
					min: 0, max: 50,
					onChange: function ( v ) { setAttributes( { readMoreBorderRadius: v } ); },
				} )
			);

			/* Couleurs du bouton "Lire la suite" — composant natif WordPress
			 * (palette du thème). Reste affiché en permanence (comportement
			 * natif des versions récentes de Gutenberg), c'est assumé. */
			var panelReadMoreColors = enableReadMore && el(
				PanelColorSettings,
				{
					title: __( 'Couleurs du bouton', 'avis-clients' ),
					initialOpen: false,
					colorSettings: [
						{
							value: attributes.readMoreTextColor,
							onChange: function ( v ) { setAttributes( { readMoreTextColor: v || '' } ); },
							label: __( 'Couleur du texte', 'avis-clients' ),
						},
						{
							value: attributes.readMoreBgColor,
							onChange: function ( v ) { setAttributes( { readMoreBgColor: v || '' } ); },
							label: __( 'Fond', 'avis-clients' ),
						},
						{
							value: attributes.readMoreBorderColor,
							onChange: function ( v ) { setAttributes( { readMoreBorderColor: v || '' } ); },
							label: __( 'Bordure', 'avis-clients' ),
						},
					],
				}
			);

			return el(
				Fragment,
				null,
				el( InspectorControls, null, panelText, panelReadMoreStyle, panelReadMoreColors ),
				el(
					'div',
					blockProps,
					el( 'div', {
						style: { color: '#aaa', fontStyle: 'italic', lineHeight: '1.6' },
					},
					el( 'p', { style: { margin: '0 0 6px' } }, __( 'Texte du témoignage client\u2026', 'avis-clients' ) ),
					el( 'p', { style: { margin: '0 0 6px', opacity: 0.7 } }, __( 'Suite de l\'avis\u2026', 'avis-clients' ) ),
					el( 'p', { style: { margin: 0, opacity: 0.4 } }, __( 'Troisi\u00e8me ligne\u2026', 'avis-clients' ) )
					)
				)
			);
		},

		save: function () {
			return null;
		},
	} );

} )();
