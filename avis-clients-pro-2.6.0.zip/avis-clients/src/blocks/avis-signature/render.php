<?php
/**
 * Rendu côté serveur pour le bloc ac/avis-signature.
 *
 * Ce fichier est appelé par WordPress lors du rendu du bloc.
 * Il récupère le nom du client (_ac_nom_client) et la date de l'avis (_ac_date_avis)
 * stockés en métadonnées du post, puis les affiche selon la configuration du bloc.
 *
 * Variables disponibles automatiquement injectées par WordPress :
 *   @var array    $attributes   Attributs du bloc (showName, showDate, separator).
 *   @var string   $content      Contenu interne du bloc (non utilisé ici).
 *   @var WP_Block $block        Instance du bloc, donne accès au contexte.
 */

/* --- Récupération du postId depuis le contexte du bloc parent (ac/avis-template) --- */
$post_id = isset( $block->context['ac/postId'] ) ? (int) $block->context['ac/postId'] : 0;

/* Si aucun post n'est associé, on n'affiche rien */
if ( ! $post_id ) {
	return '';
}

/* --- Récupération des attributs de configuration du bloc --- */
$show_name = isset( $attributes['showName'] ) ? (bool) $attributes['showName'] : true;
$show_date = isset( $attributes['showDate'] ) ? (bool) $attributes['showDate'] : true;
$separator = isset( $attributes['separator'] ) ? $attributes['separator'] : '·';
$show_verified = isset( $attributes['showVerified'] ) ? (bool) $attributes['showVerified'] : true;
$show_source   = isset( $attributes['showSource'] ) ? (bool) $attributes['showSource'] : true;

/*
 * Si aucun des trois éléments n'est activé, on n'émet aucun HTML
 * pour éviter un rendu vide qui occuperait de l'espace.
 * (Le badge Source est indépendant de Nom/Date : il ne doit pas être
 * escamoté simplement parce que ces deux-là sont désactivés.)
 */
if ( ! $show_name && ! $show_date && ! $show_source ) {
	return '';
}

/* --- Récupération des métadonnées du post --- */
$nom_client = get_post_meta( $post_id, '_ac_nom_client', true );
$date_avis  = get_post_meta( $post_id, '_ac_date_avis', true );
$verified   = get_post_meta( $post_id, '_ac_verified', true );
$source     = get_post_meta( $post_id, '_ac_source', true );

/*
 * Si aucun des éléments effectivement activés n'a de valeur en base,
 * on n'affiche rien plutôt qu'une signature vide.
 */
$has_name   = $show_name && $nom_client;
$has_date   = $show_date && $date_avis;
$has_source = $show_source && $source;
if ( ! $has_name && ! $has_date && ! $has_source ) {
	return '';
}

/* F3 : Gestion de la police personnalisée — fichier importé (prioritaire,
 * @font-face généré par ac_enqueue_custom_font_face()) ou nom Google Fonts.
 * Sans ça, la police du thème (support natif typography.fontFamily) s'applique. */
$custom_font     = isset( $attributes['customFont'] ) ? trim( $attributes['customFont'] ) : '';
$custom_font_url = isset( $attributes['customFontUrl'] ) ? esc_url_raw( $attributes['customFontUrl'] ) : '';
$google_fonts_html = '';
$custom_font_style = '';

if ( ! empty( $custom_font_url ) && ! empty( $custom_font ) ) {
	if ( function_exists( 'ac_enqueue_custom_font_face' ) ) {
		ac_enqueue_custom_font_face( $custom_font, $custom_font_url );
	}
	$custom_font_style = 'font-family: "' . esc_attr( $custom_font ) . '" !important;';
} elseif ( ! empty( $custom_font ) ) {
	$primary_font = trim( str_replace( ['"', "'"], '', explode( ',', $custom_font )[0] ) );
	$system_fonts = ['Arial', 'Helvetica', 'Verdana', 'Georgia', 'Times New Roman', 'sans-serif', 'serif', 'monospace', 'inherit', 'initial'];

	if ( strpos( $primary_font, 'var(' ) === false && ! in_array( $primary_font, $system_fonts ) ) {
		$fonts_url = 'https://fonts.googleapis.com/css2?family=' . urlencode( $primary_font ) . ':wght@400;500;600;700;800;900&display=swap';
		$google_fonts_html = '<link href="' . esc_url( $fonts_url ) . '" rel="stylesheet">';
		$custom_font_style = 'font-family: ' . esc_attr( $custom_font ) . ' !important;';
	}
}

/*
 * Construction des attributs du wrapper du bloc.
 * get_block_wrapper_attributes() ajoute automatiquement les classes et styles
 * générés par les supports du bloc (couleur, espacement, typographie…).
 * On y ajoute la classe CSS personnalisée du plugin.
 */
$wrapper_args = array( 'class' => 'ac-avis-signature' );
if ( ! empty( $custom_font_style ) ) {
	$wrapper_args['style'] = $custom_font_style;
}
$wrapper_attributes = get_block_wrapper_attributes( $wrapper_args );

/* --- Génération du HTML final --- */
ob_start();
?>
<?php echo $google_fonts_html; // Tag link injecté si une Google Font personnalisée est demandée ?>
<div <?php echo $wrapper_attributes; // Les attributs du wrapper sont générés par WP, sûrs ?>>

	<?php if ( $show_name && $nom_client ) : ?>
		<?php /* Nom du client : encapsulé dans un span pour un ciblage CSS précis */ ?>
		<span class="ac-avis-auteur"><?php echo esc_html( $nom_client ); ?></span>
        
        <?php if ( $show_verified && $verified ) : ?>
            <span class="ac-badge-verified" title="<?php esc_attr_e( 'Achat vérifié', 'avis-clients' ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#34d058"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            </span>
        <?php endif; ?>
	<?php endif; ?>

	<?php if ( $show_name && $nom_client && ( $show_date && $date_avis || $show_source && $source ) ) : ?>
		<?php /* Séparateur entre le nom et la date, affiché uniquement si les deux sont présents */ ?>
		<span class="ac-avis-sep" aria-hidden="true"><?php echo esc_html( $separator ); ?></span>
	<?php endif; ?>

	<?php if ( $show_date && $date_avis ) : ?>
		<?php /* Date de l'avis : encapsulée dans un span pour un ciblage CSS précis */ ?>
		<span class="ac-avis-date"><?php echo esc_html( $date_avis ); ?></span>
	<?php endif; ?>

    <?php if ( $show_source && $source ) : ?>
        <span class="ac-badge-source ac-source-<?php echo esc_attr( strtolower( $source ) ); ?>" title="<?php echo esc_attr( $source ); ?>">
            <?php 
            if ( strtolower( $source ) === 'google' ) {
                echo '<svg width="14" height="14" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>';
            } elseif ( strtolower( $source ) === 'facebook' ) {
                echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>';
            } elseif ( strtolower( $source ) === 'trustpilot' ) {
                echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="#00B67A"><path d="M24 8.76l-9.17-.66L12 0 9.17 8.1 0 8.76l6.63 6.32-1.57 9.07L12 19.34l6.94 4.81-1.57-9.07L24 8.76z"/></svg>';
            } else {
                echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="#888"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>';
            }
            ?>
        </span>
    <?php endif; ?>

</div>
<?php
echo ob_get_clean();
