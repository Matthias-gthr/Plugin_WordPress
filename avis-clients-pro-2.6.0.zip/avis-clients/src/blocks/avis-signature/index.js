/**
 * Bloc Gutenberg : ac/avis-signature
 *
 * Affiche le nom du client et la date de l'avis dans le contexte du template ac/avis-template.
 * Le rendu réel est délégué à render.php ; save() retourne null (bloc dynamique).
 *
 * Dépendances : wp-blocks, wp-block-editor, wp-components, wp-element, wp-i18n
 */

( function () {
	'use strict';

	/* --- Récupération des API WordPress depuis l'objet global --- */
	var registerBlockType  = wp.blocks.registerBlockType;
	var el                 = wp.element.createElement;
	var Fragment           = wp.element.Fragment;
	var __                 = wp.i18n.__;
	var useBlockProps      = wp.blockEditor.useBlockProps;
	var InspectorControls  = wp.blockEditor.InspectorControls;
	var PanelBody          = wp.components.PanelBody;
	var ToggleControl      = wp.components.ToggleControl;
	var TextControl        = wp.components.TextControl;
	var Button             = wp.components.Button;
	var MediaUpload        = wp.blockEditor.MediaUpload;
	var MediaUploadCheck   = wp.blockEditor.MediaUploadCheck;

	/* Contrôle de police partagé : voir avis-title/index.js pour le détail.
	 * "Police du thème" reste géré nativement par WordPress (support
	 * typography.fontFamily déclaré dans block.json) ; ici on ajoute le nom
	 * Google Fonts et l'import d'un vrai fichier de police, exclusifs entre eux. */
	function renderFontControl( attributes, setAttributes ) {
		var hasFile = !! attributes.customFontUrl;
		return el( Fragment, null,
			el( TextControl, {
				label:    __( 'Police Google Font (nom exact)', 'avis-clients' ),
				value:    attributes.customFont,
				help:     hasFile
					? __( 'Désactivé : un fichier de police importé est actif.', 'avis-clients' )
					: __( 'Exemple: Montserrat, Roboto, Open Sans. Laissez vide pour utiliser la police du thème.', 'avis-clients' ),
				disabled: hasFile,
				onChange: function ( v ) { setAttributes( { customFont: v } ); },
			} ),
			el( MediaUploadCheck, null,
				el( MediaUpload, {
					onSelect: function ( media ) {
						setAttributes( {
							customFontUrl: media.url,
							customFont:    attributes.customFont || media.title || 'Police importée',
						} );
					},
					render: function ( obj ) {
						return el( Button, {
							variant: 'secondary',
							onClick: obj.open,
							style: { marginTop: '8px' },
						}, hasFile
							? __( 'Changer le fichier de police', 'avis-clients' )
							: __( 'Importer un fichier de police', 'avis-clients' )
						);
					},
				} )
			),
			hasFile && el( 'div', { style: { marginTop: '6px', fontSize: '12px' } },
				el( 'code', {}, attributes.customFontUrl.split( '/' ).pop() ),
				' — ',
				el( Button, {
					variant: 'link',
					isDestructive: true,
					onClick: function () { setAttributes( { customFontUrl: '' } ); },
				}, __( 'Retirer', 'avis-clients' ) )
			)
		);
	}

	/* --- Enregistrement du bloc --- */
	registerBlockType( 'ac/avis-signature', {

		/**
		 * Fonction d'édition : affichage dans l'éditeur Gutenberg.
		 * Affiche un placeholder "Jean Dupont · Janvier 2025".
		 * La sidebar propose : afficher/masquer le nom, afficher/masquer la date,
		 * et personnaliser le séparateur entre les deux.
		 *
		 * @param {Object} props - Propriétés du bloc (attributes, setAttributes).
		 */
		edit: function ( props ) {
			var attributes    = props.attributes;
			var setAttributes = props.setAttributes;
			var showName     = attributes.showName;
			var showDate     = attributes.showDate;
			var separator    = attributes.separator;
			var showVerified = attributes.showVerified;
			var showSource   = attributes.showSource;

			/* Propriétés du wrapper bloc */
			var blockProps = useBlockProps( {
				style: { display: 'block' },
			} );

			return el(
				Fragment,
				null,

				/* --- Panneau de configuration dans la sidebar --- */
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{
							title: __( 'Réglages de la signature', 'avis-clients' ),
							initialOpen: true,
						},

						/* Affichage du nom du client */
						el( ToggleControl, {
							label:    __( 'Afficher le nom du client', 'avis-clients' ),
							checked:  showName,
							onChange: function ( nouvelleValeur ) {
								setAttributes( { showName: nouvelleValeur } );
							},
						} ),

						/* Affichage de la date de l'avis */
						el( ToggleControl, {
							label:    __( 'Afficher la date', 'avis-clients' ),
							checked:  showDate,
							onChange: function ( nouvelleValeur ) {
								setAttributes( { showDate: nouvelleValeur } );
							},
						} ),

						/* Personnalisation du séparateur entre le nom et la date */
						el( TextControl, {
							label:    __( 'Séparateur', 'avis-clients' ),
							value:    separator,
							help:     __( 'Caractère(s) affiché(s) entre le nom et la date.', 'avis-clients' ),
							onChange: function ( nouvelleValeur ) {
								setAttributes( { separator: nouvelleValeur } );
							},
						} ),
						
						/* Affichage du badge Achat Vérifié */
						el( ToggleControl, {
							label:    __( 'Afficher le badge "Achat vérifié"', 'avis-clients' ),
							checked:  showVerified,
							onChange: function ( v ) { setAttributes( { showVerified: v } ); },
						} ),

						/* Affichage de la source (Google, etc.) */
						el( ToggleControl, {
							label:    __( 'Afficher la source', 'avis-clients' ),
							checked:  showSource,
							onChange: function ( v ) { setAttributes( { showSource: v } ); },
						} ),

						/* Police (Google Fonts ou fichier importé) */
						renderFontControl( attributes, setAttributes )
					)
				),

				/* --- Aperçu dans l'éditeur : placeholder de signature en gris --- */
				el(
					'div',
					blockProps,
					el(
						'p',
						{
							style: {
								color:      '#aaa',
								fontStyle:  'italic',
								margin:     0,
								fontSize:   '0.9em',
							},
						},
						/* Construction du placeholder selon les options actives */
						( showName ? 'Jean Dupont' : '' )
						+ ( showName && showDate ? ' ' + separator + ' ' : '' )
						+ ( showDate ? 'Janvier 2025' : '' )
						|| __( '(aucun élément sélectionné)', 'avis-clients' )
					)
				)
			);
		},

		/**
		 * save() retourne null car ce bloc est dynamique :
		 * le rendu HTML est entièrement géré côté serveur dans render.php.
		 *
		 * @returns {null}
		 */
		save: function () {
			return null;
		},
	} );

} )();
