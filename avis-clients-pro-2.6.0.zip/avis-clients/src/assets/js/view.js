/**
 * Scripts front-end : Carousel + Slider — v2
 *
 * Chargé via "viewScript" dans block.json uniquement quand le bloc est présent.
 * Gère les layouts carousel ET slider (même logique, styles différents).
 * Les marquees sont 100% CSS (@keyframes), pas de JS nécessaire.
 *
 * @since 1.5.0
 */
( function() {
    'use strict';

    function initCarousel( container ) {

        var viewport      = container.querySelector( '.ac-carousel-viewport' );
        var track         = container.querySelector( '.ac-carousel-track' );
        var prevBtn       = container.querySelector( '.ac-carousel-prev' );
        var nextBtn       = container.querySelector( '.ac-carousel-next' );
        var dotsContainer = container.querySelector( '.ac-carousel-dots' );

        if ( ! viewport || ! track ) return;

        var slides = track.querySelectorAll( '.ac-carte-avis' );
        if ( slides.length === 0 ) return;

        var autoplayEnabled     = container.dataset.autoplay === 'true';
        var continuousEnabled   = container.dataset.continuous === 'true';
        var speed               = parseInt( container.dataset.speed, 10 ) || 5000;
        var autoplayTimer       = null;
        var scrollTimeout       = null;
        var animationFrameId    = null;
        var continuousScrollPos = 0;
        
        if ( autoplayEnabled && continuousEnabled ) {
            viewport.classList.add('ac-continuous-scroll');
        }

        /**
         * Calcule la valeur maximale de défilement (scrollLeft)
         * possible pour la piste du carrousel.
         */
        function getMaxScroll() {
            return Math.max(0, track.scrollWidth - viewport.clientWidth);
        }

        /**
         * Détermine l'index de la carte la plus proche du bord gauche actuel.
         * On utilise offsetLeft pour une précision absolue, quelles que
         * soient les dimensions des éléments.
         */
        function getCurrentIndex() {
            var scrollLeft = viewport.scrollLeft;
            var closestIndex = 0;
            var minDiff = Infinity;
            
            for ( var i = 0; i < slides.length; i++ ) {
                // Distance exacte de la carte par rapport au début de la piste
                var slideOffset = slides[ i ].offsetLeft - track.offsetLeft;
                var diff = Math.abs( slideOffset - scrollLeft );
                
                // Si cette carte est la plus proche du scroll actuel, on la retient
                if ( diff < minDiff ) {
                    minDiff = diff;
                    closestIndex = i;
                }
            }
            return closestIndex;
        }

        /**
         * Fait défiler le viewport jusqu'à l'index spécifié.
         * Utilise nativement scrollTo() pour s'accorder parfaitement avec CSS Scroll Snap.
         */
        function goTo( index ) {
            // Boucler si l'index est hors limites
            if ( index < 0 ) index = slides.length - 1;
            if ( index >= slides.length ) index = 0;
            
            var targetScroll = slides[ index ].offsetLeft - track.offsetLeft;
            
            // Ne pas scroller au-delà du max possible pour éviter les bugs visuels
            targetScroll = Math.min( targetScroll, getMaxScroll() );
            
            viewport.scrollTo({ left: targetScroll, behavior: 'smooth' });
        }

        function next() { 
            var currentIdx = getCurrentIndex();
            // Si on est déjà au max du scroll, on retourne au début
            if ( viewport.scrollLeft >= getMaxScroll() - 10 ) {
                goTo( 0 );
            } else {
                goTo( currentIdx + 1 );
            }
        }

        function prev() { 
            var currentIdx = getCurrentIndex();
            if ( viewport.scrollLeft <= 10 ) {
                // Aller tout à la fin
                viewport.scrollTo({ left: getMaxScroll(), behavior: 'smooth' });
            } else {
                goTo( currentIdx - 1 );
            }
        }

        function createDots() {
            if ( ! dotsContainer ) return;
            dotsContainer.innerHTML = '';
            
            if ( slides.length <= 1 ) return;
            
            for ( var j = 0; j < slides.length; j++ ) {
                var dot       = document.createElement( 'button' );
                dot.className = 'ac-dot' + ( j === 0 ? ' ac-dot-active' : '' );
                dot.setAttribute( 'type', 'button' );
                /* translators: %d = numéro de la diapositive */
                dot.setAttribute( 'aria-label', 'Diapositive ' + ( j + 1 ) );
                dot.setAttribute( 'aria-current', j === 0 ? 'true' : 'false' );
                dot.dataset.index = j;
                dot.addEventListener( 'click', function() {
                    goTo( parseInt( this.dataset.index, 10 ) );
                    resetAutoplay();
                } );
                dotsContainer.appendChild( dot );
            }
            updateDots();
        }

        function updateDots() {
            if ( ! dotsContainer ) return;
            var dots = dotsContainer.querySelectorAll( '.ac-dot' );
            if ( ! dots.length ) return;
            
            var currentIdx = getCurrentIndex();
            for ( var i = 0; i < dots.length; i++ ) {
                var isActive = ( i === currentIdx );
                dots[ i ].classList.toggle( 'ac-dot-active', isActive );
                dots[ i ].setAttribute( 'aria-current', isActive ? 'true' : 'false' );
            }
        }

        // Ecouter le défilement natif pour mettre à jour les dots
        viewport.addEventListener( 'scroll', function() {
            clearTimeout( scrollTimeout );
            scrollTimeout = setTimeout( updateDots, 50 );
        }, { passive: true } );

        if ( prevBtn ) prevBtn.addEventListener( 'click', function() { prev(); resetAutoplay(); } );
        if ( nextBtn ) nextBtn.addEventListener( 'click', function() { next(); resetAutoplay(); } );

        function startAutoplay() {
            if ( ! autoplayEnabled ) return;
            stopAutoplay();
            
            if ( continuousEnabled ) {
                continuousScrollPos = viewport.scrollLeft;
                // Calcul de la vitesse par frame : speed représente ici une durée relative pour la vitesse.
                var pxPerFrame = Math.max(0.2, 5000 / speed); 
                
                function loop() {
                    continuousScrollPos += pxPerFrame;
                    
                    // Si on arrive au bout, on repart à zéro
                    if ( continuousScrollPos >= getMaxScroll() ) {
                        continuousScrollPos = 0;
                        viewport.scrollTo({ left: 0, behavior: 'auto' }); // Instantané
                    } else {
                        viewport.scrollTo({ left: continuousScrollPos, behavior: 'auto' });
                    }
                    animationFrameId = requestAnimationFrame(loop);
                }
                animationFrameId = requestAnimationFrame(loop);
            } else {
                // Défilement par saut de carte
                autoplayTimer = setInterval( next, speed );
            }
        }
        function stopAutoplay() {
            if ( autoplayTimer ) { clearInterval( autoplayTimer ); autoplayTimer = null; }
            if ( animationFrameId ) { cancelAnimationFrame( animationFrameId ); animationFrameId = null; }
        }
        function resetAutoplay() { 
            stopAutoplay(); 
            // Pour le continu, on attend un instant avant de reprendre si on clique
            if ( continuousEnabled ) {
                setTimeout(startAutoplay, 2000);
            } else {
                startAutoplay();
            }
        }

        container.addEventListener( 'mouseenter', stopAutoplay );
        container.addEventListener( 'mouseleave', function() { if ( autoplayEnabled ) startAutoplay(); } );

        // Lors d'un drag manuel ou swipe, synchroniser la position continue
        viewport.addEventListener( 'scroll', function() {
            if ( autoplayEnabled && continuousEnabled ) {
                continuousScrollPos = viewport.scrollLeft;
            }
        }, { passive: true } );

        /* Clavier */
        container.addEventListener( 'keydown', function( e ) {
            if ( e.key === 'ArrowLeft' )  { prev(); resetAutoplay(); }
            if ( e.key === 'ArrowRight' ) { next(); resetAutoplay(); }
        } );

        /* Resize */
        var resizeTimeout;
        window.addEventListener( 'resize', function() {
            clearTimeout( resizeTimeout );
            resizeTimeout = setTimeout( function() { 
                createDots(); 
            }, 200 );
        } );

        /* Init */
        container.setAttribute( 'tabindex', '0' );
        container.setAttribute( 'role', 'region' );
        container.setAttribute( 'aria-roledescription', 'carousel' );
        container.setAttribute( 'aria-label', 'Avis clients' );
        
        // Laisser le temps au DOM de calculer la largeur
        setTimeout(function() {
            createDots();
            startAutoplay();
        }, 100);
    }

    function init() {
        var els = document.querySelectorAll( '.ac-layout-carousel' );
        for ( var i = 0; i < els.length; i++ ) {
            if ( ! els[ i ].dataset.acInitialized ) {
                els[ i ].dataset.acInitialized = 'true';
                initCarousel( els[ i ] );
            }
        }
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', init );
    } else {
        init();
    }

    /**
     * Gestion du bouton "Voir plus" (Textes longs)
     */
    function initReadMore() {
        var buttons = document.querySelectorAll( '.ac-read-more-btn' );
        for ( var i = 0; i < buttons.length; i++ ) {
            if ( ! buttons[ i ].dataset.acInitialized ) {
                buttons[ i ].dataset.acInitialized = 'true';
                
                var wrapper = buttons[ i ].closest( '.ac-avis-texte-wrapper' );
                var textElement = wrapper ? wrapper.querySelector( '.ac-avis-texte' ) : null;
                
                if ( textElement ) {
                    // Vérifier si le texte déborde réellement
                    (function(btn, txt, wrap) {
                        setTimeout(function() {
                            // On compare la hauteur totale (scrollHeight) à la hauteur visible contrainte (clientHeight)
                            if ( txt.scrollHeight <= txt.clientHeight + 2 ) {
                                btn.style.display = 'none';
                                wrap.classList.remove('ac-read-more-enabled');
                            }
                        }, 100);
                    })(buttons[ i ], textElement, wrapper);
                }

                buttons[ i ].addEventListener( 'click', function() {
                    var wrapper = this.closest( '.ac-avis-texte-wrapper' );
                    if ( wrapper ) {
                        var isExpanded = wrapper.classList.toggle( 'ac-expanded' );
                        this.setAttribute( 'aria-expanded', isExpanded ? 'true' : 'false' );
                        this.textContent = isExpanded
                            ? ( this.dataset.labelLess || 'Voir moins' )
                            : ( this.dataset.labelMore || 'Lire la suite' );
                    }
                } );
            }
        }
    }
    
    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', initReadMore );
    } else {
        initReadMore();
    }

    function initObserver() {
        if ( typeof MutationObserver !== 'undefined' && document.body ) {
            var observer = new MutationObserver( function( mutations ) {
                var needsInit = false;
                for ( var i = 0; i < mutations.length; i++ ) {
                    if ( mutations[ i ].addedNodes.length > 0 ) {
                        for ( var j = 0; j < mutations[ i ].addedNodes.length; j++ ) {
                            var node = mutations[ i ].addedNodes[ j ];
                            if ( node.nodeType === 1 ) {
                                // Vérifier si le nœud ajouté est ou contient un carrousel
                                if ( node.classList && node.classList.contains( 'ac-conteneur-avis' ) ) {
                                    needsInit = true;
                                } else if ( node.querySelector && node.querySelector( '.ac-conteneur-avis' ) ) {
                                    needsInit = true;
                                }
                            }
                        }
                    }
                }
                // Si on a détecté un nouveau carrousel, on lance l'init
                if ( needsInit ) {
                    setTimeout( function() {
                        init();
                        initReadMore();
                    }, 50 );
                }
            });
            observer.observe( document.body, { childList: true, subtree: true } );
        }
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', initObserver );
    } else {
        initObserver();
    }

} )();