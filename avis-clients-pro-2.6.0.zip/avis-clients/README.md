# Plugin Avis Clients Pro 🌟

Bienvenue dans **Avis Clients Pro**, l'extension WordPress pour collecter, gérer et afficher facilement les témoignages de vos clients avec un rendu premium.

Pensé pour la conversion et l'impact visuel, ce plugin vous offre des outils d'affichage dignes des plus grandes plateformes SaaS (façon Senja.io ou Trustpilot) tout en s'intégrant à l'écosystème natif de WordPress (Gutenberg, FSE).

---

## 🚀 Fonctionnalités principales

- **Système de collecte intégré :** un formulaire de soumission (avec photo facultative) pour que vos clients laissent leur avis directement depuis le site. Chaque soumission est enregistrée en attente de relecture, et **vous êtes prévenu par email**.
- **Gestion native simplifiée :** un type de publication dédié "Avis clients" avec colonnes (note, client, source, vérifié) et un badge de comptage des avis en attente sur le menu — vous ne ratez plus rien.
- **Architecture modulaire Gutenberg :** un système de blocs imbriqués permettant de personnaliser individuellement chaque composant (Titre, Étoiles, Avatar, Contenu, Signature) via l'éditeur.
- **Prévisualisation 100% WYSIWYG :** l'éditeur affiche exactement le même rendu que le site final.
- **Import de police et d'icône personnalisée :** importez un fichier de police (.woff2/.ttf...) ou une icône SVG pour la notation, en plus des options prêtes à l'emploi.
- **SEO & Schema.org intégré :** calcul automatique de la note moyenne, injection du JSON-LD (`AggregateRating`) pour les étoiles dans les résultats Google — avec le choix du type d'entité (établissement local, produit ou marque).
- **Anti-spam à plusieurs niveaux :** honeypot + limite de fréquence par IP + validation stricte des longueurs sur le formulaire public.
- **Logique "Lire la suite" intelligente :** le bouton ne s'affiche que si le texte dépasse réellement la taille de la carte.

---

## 💡 Les 5 mises en page disponibles

Le bloc principal `Avis Clients` propose 5 types d'affichage :

1. **▦ Grille & Mosaïque :** disposition classique en colonnes responsives, ou grille déstructurée où les cartes s'imbriquent selon la longueur du texte. Une **pagination** ("Page suivante/précédente") peut être activée au-delà du nombre d'avis affichés.

2. **⟵ Carrousel :** diaporama interactif avec flèches, points de pagination et défilement automatique (par saut ou continu).

3. **→ Défilement continu (Marquee) :** les avis défilent tout seuls en boucle infinie, pause automatique au survol.

4. **🏆 Badge / Preuve sociale :** résumé compact (ex. "4.5/5 basé sur 120 avis"), idéal sous un bouton d'achat ou en pied de page. 4 styles visuels au choix.

5. **📸 Galerie visuelle :** met l'accent sur les images avec des textes superposés.

---

## 📖 Comment collecter et gérer les avis ?

### 1. Collecter les avis via le formulaire

1. Éditez une page et ajoutez le bloc **Formulaire d'avis**.
2. Vos clients y laissent leur note sur 5, leur nom, leur commentaire et — optionnellement — une photo.
3. Le formulaire est protégé par un honeypot invisible et une limite de 5 soumissions par IP toutes les 10 minutes.
4. À la soumission, l'avis est créé en statut **En attente de relecture**, et vous recevez un email avec un lien direct pour le valider.

### 2. Gérer et ajouter manuellement des avis

1. Dans le menu de gauche, cliquez sur **Avis clients** — un badge indique le nombre d'avis en attente.
2. La liste affiche directement la note (★), le client, la source et le badge "vérifié" pour chaque avis, avec un tri possible par note.
3. Pour ajouter un avis manuellement : **Ajouter un nouvel avis**, puis remplissez :
   - **Titre** et **contenu** de l'avis
   - **Image mise en avant** (photo du client)
   - **Note sur 5**, **nom du client**, **date**, **source** (Google, Trustpilot, Manuel…)
   - **Achat vérifié** (case à cocher) et **lien externe** vers l'avis d'origine si pertinent

---

## 🎨 Comment afficher et personnaliser les avis ?

1. Ajoutez le bloc parent **Avis Clients** (`ac/avis-query`) sur une page. Dans la sidebar, configurez :
   - Le nombre d'avis, le tri (date/note/aléatoire), les catégories, la note minimale
   - Le type de mise en page et sa variante visuelle
   - Le type d'entité Schema.org pour le SEO
2. **Personnalisation de la carte :** sélectionnez le bloc "Modèle d'avis" (caché dans la structure, visible via la *Vue en liste*) pour régler couleur de fond, ombre, animations de survol (Lift, Scale, Tilt, Glow), **arrondi des coins** et **espacement entre les blocs enfants** (panneau dédié "Apparence de la carte", fiable même quand les panneaux natifs de bordure/espacement ne s'affichent pas correctement selon votre configuration).
3. **Personnalisation des éléments internes :** chaque élément (Avatar, Étoiles, Titre, Contenu, Signature) est un bloc indépendant, réordonnable par glisser-déposer. Réglez leur couleur, taille, marges via les contrôles natifs.
4. **Typographie :** utilisez la police du thème (menu natif) ou importez la vôtre — nom Google Fonts ou fichier `.woff2`/`.ttf` via la médiathèque.
5. **Icône de notation :** choisissez parmi 8 icônes prêtes à l'emploi (étoile, cœur, pouce, feu, check, diamant, couronne, sourire) ou importez votre propre SVG.
6. **Arrondi et espacement du conteneur global** et **espacement entre les avis** : réglables directement dans le panneau "Mise en page" du bloc parent.

Toutes ces modifications apparaissent **instantanément** dans l'éditeur.

---

## 🔒 Sécurité et confidentialité

- **Formulaire public protégé** : honeypot, limite de fréquence par IP, validation stricte (longueur, type de note).
- **Uploads restreints** : les fichiers de police sont autorisés pour les auteurs et plus ; **l'import de SVG est réservé aux administrateurs** et automatiquement nettoyé (suppression de tout script ou gestionnaire d'événement) dès l'upload.
- **Désinstallation propre** : si vous supprimez le plugin depuis l'écran Extensions, tous les avis, catégories et données temporaires associées sont nettoyés (pensez à exporter avant si besoin).

---

## 🛠️ Détails techniques

- **Architecture Gutenberg moderne :** API Block Supports, contexte de bloc (`providesContext`/`usesContext`), `ServerSideRender` avec sérialisation de l'état en direct pour le WYSIWYG.
- **Code 100% Vanilla JS & PHP natif :** aucun framework lourd, aucune dépendance frontend externe.
- **Mise en cache intelligente :** fichiers statiques versionnés par `filemtime()` pour éviter tout problème de cache après mise à jour.
- **API REST WordPress standard** pour les soumissions du formulaire, données validées et nettoyées strictement (`wp_kses`, `sanitize_text_field`, `esc_url_raw`…).
- **Compatibilité :** WordPress 6.5+, PHP 7.4+.

Pour le détail complet (attributs de chaque bloc, hooks disponibles, structure des fichiers, limites connues), voir [`documentation.md`](documentation.md).

---

*Développé avec passion pour augmenter les conversions de votre site web.*
