<?php
/**
 * Désinstallation du plugin Avis Clients Pro.
 *
 * WordPress appelle ce fichier uniquement quand l'utilisateur clique sur
 * "Supprimer" dans l'écran Extensions (jamais à une simple désactivation).
 * On nettoie ce que le plugin a créé : les avis (posts + meta), les termes
 * de la taxonomie "Catégories d'avis", et les transients de limitation de
 * fréquence du formulaire.
 *
 * @package Avis_Clients
 */

// Garde-fou standard WordPress : ce fichier ne doit jamais s'exécuter
// autrement que via le processus officiel de désinstallation.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// 1) Suppression de tous les avis (posts + toutes leurs métadonnées et
//    relations, y compris les révisions). wp_delete_post() avec force_delete
//    à true contourne la corbeille et supprime réellement l'enregistrement.
$avis_ids = get_posts([
    'post_type'      => 'avis_client',
    'post_status'    => 'any',
    'numberposts'    => -1,
    'fields'         => 'ids',
    'suppress_filters' => true,
]);

foreach ( $avis_ids as $avis_id ) {
    wp_delete_post( $avis_id, true );
}

// 2) Suppression des termes de la taxonomie "categorie_avis" : cette
//    taxonomie n'existe que pour ce plugin, ses termes n'ont donc plus
//    aucun sens une fois le plugin retiré.
$termes = get_terms([
    'taxonomy'   => 'categorie_avis',
    'hide_empty' => false,
    'fields'     => 'ids',
]);

if ( ! is_wp_error( $termes ) ) {
    foreach ( $termes as $terme_id ) {
        wp_delete_term( $terme_id, 'categorie_avis' );
    }
}

// 3) Nettoyage des transients de limitation de fréquence du formulaire
//    (clés dynamiques par IP, non énumérables via l'API transients).
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '_transient_ac_rate_%'
        OR option_name LIKE '_transient_timeout_ac_rate_%'"
);
