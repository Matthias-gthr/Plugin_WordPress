<?php
/**
 * Plugin Name: Avis Clients Pro
 * Description: Gestion interne des avis clients avec bloc Gutenberg dynamique.
 * Version: 2.6.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Matthieu
 * License: GPL2
 * Text Domain: avis-clients
 * Domain Path: /languages
 *
 * Ce commentaire d'en-tête est obligatoire. WordPress l'utilise pour afficher
 * les informations du plugin dans l'écran "Extensions" de l'administration.
 *
 * "Requires at least" est fixé par le support de bloc le plus exigeant
 * utilisé (background.backgroundImage sur ac/avis-query, introduit en 6.5).
 */

// SÉCURITÉ : Si ce fichier est appelé directement par un utilisateur via son navigateur 
// (ex: domaine.local/wp-content/plugins/avis-clients/avis-clients.php), on arrête tout.
// ABSPATH est une constante définie par WordPress uniquement quand le cœur est chargé.
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}



/**
 * ÉTAPE 1 : Enregistrement du Custom Post Type (CPT) "Avis clients"
 * On crée un type de contenu dédié, séparé des Articles et des Pages.
 */
function ac_enregistrer_cpt_avis() {

    // Les labels définissent les textes affichés dans les menus de l'administration
    $labels = [
        'name'               => 'Avis clients',          // Nom général dans le menu de gauche
        'singular_name'      => 'Avis client',           // Nom au singulier
        'menu_name'          => 'Avis clients',          // Libellé exact du menu
        'add_new'            => 'Ajouter un avis',       // Bouton ajouter
        'add_new_item'       => 'Ajouter un nouvel avis', // Titre de la page de création
        'edit_item'          => 'Modifier l\'avis',       // Titre de la page de modification
        'all_items'          => 'Tous les avis',         // Sous-menu de la liste
    ];

    // Les arguments de configuration du type de contenu
    $args = [
        'labels'             => $labels,
        'public'             => false, // Sécurité & SEO : On ne veut pas que Google indexe des pages d'avis isolées (ex: /avis/avis-de-jean/)
        'show_ui'            => true,  // Mais on veut qu'il soit visible et gérable dans l'administration
        'show_in_menu'       => true,  // Affiche l'onglet dans la barre latérale de l'admin
        'query_var'          => true,
        'capability_type'    => 'post', // Utilise les mêmes permissions que les articles (seuls les admins/éditeurs peuvent y toucher)
        'has_archive'        => false, // Pas de page d'archive automatique /avis/
        'hierarchical'       => false, // Les avis ne dépendent pas les uns des autres (pas de relation parent/enfant)
        'menu_icon'          => 'dashicons-testimonial', // Icône officielle WordPress (une bulle de témoignage)
        
        // Les fonctionnalités natives de WP qu'on réutilise (cf. section 5 de la spec)
        // 'title' = Titre de l'avis
        // 'editor' = Corps de texte de l'avis
        // 'thumbnail' = Image mise en avant (la photo ou l'avatar du client)
        'supports'           => [ 'title', 'editor', 'thumbnail' ], 
        
        // CRUCIAL POUR WORDPRESS 7.0 & GUTENBERG :
        // Active l'API REST de WordPress pour ce contenu. Sans ça, impossible d'utiliser 
        // l'éditeur de blocs moderne (Gutenberg) ou de lier les données à notre bloc.
        'show_in_rest'       => true,  
    ];

    // Fonction native qui enregistre officiellement la structure auprès de WordPress
    register_post_type( 'avis_client', $args );
}
// On demande à WordPress de déclencher notre fonction lors de son initialisation ('init')
add_action( 'init', 'ac_enregistrer_cpt_avis' );


/**
 * ÉTAPE 2 : Enregistrement de la Taxonomie (Catégories d'avis)
 * Permet de classer les avis (ex: Site web, Formation, Notion...)
 */
function ac_enregistrer_taxonomie_avis() {

    $labels = [
        'name'          => 'Catégories d\'avis',
        'singular_name' => 'Catégorie d\'avis',
        'search_items'  => 'Chercher une catégorie',
        'all_items'     => 'Toutes les catégories',
        'edit_item'     => 'Modifier la catégorie',
        'update_item'   => 'Mettre à jour la catégorie',
        'add_new_item'  => 'Ajouter une nouvelle catégorie',
        'menu_name'     => 'Catégories d\'avis',
    ];

    $args = [
        'labels'            => $labels,
        'hierarchical'      => true, // true = cases à cocher (comme les catégories), false = tags/mots-clés
        'show_admin_column' => true, // Affiche une colonne "Catégories" dans la liste des avis de l'admin
        'show_in_rest'      => true, // Obligatoire pour que la sélection de catégorie apparaisse dans Gutenberg
    ];

    // On lie cette taxonomie au type de contenu créé juste au-dessus ('avis_client')
    register_taxonomy( 'categorie_avis', [ 'avis_client' ], $args );
}
add_action( 'init', 'ac_enregistrer_taxonomie_avis' );


/**
 * ÉTAPE 3 : Déclaration et enregistrement des métadonnées (Champs personnalisés)
 * Pour stocker la note, le nom du client, la date de l'avis et préparer la V2.
 */
function ac_enregistrer_meta_avis() {

    // Les clés préfixées par "_" sont des metas "protégées" pour WordPress.
    // Pour qu'elles restent modifiables via l'API REST (utilisée par Gutenberg),
    // la doc impose de fournir un auth_callback qui autorise les utilisateurs habilités.
    $auth_callback = function() {
        return current_user_can( 'edit_posts' );
    };

    // 1. Champ pour la Note (Nombre entier)
    register_post_meta( 'avis_client', '_ac_note', [
        'show_in_rest' => true, // Rend le champ accessible via l'API pour l'éditeur Gutenberg
        'single'       => true, // Une seule valeur par avis (pas un tableau)
        'type'         => 'integer',
        'auth_callback' => $auth_callback,
        // Sécurité : On nettoie la donnée reçue. Elle doit être comprise strictement entre 1 et 5.
        'sanitize_callback' => function( $value ) {
            return min( 5, max( 1, intval( $value ) ) );
        }
    ]);

    // 2. Champ pour le Nom du client (Texte simple)
    register_post_meta( 'avis_client', '_ac_nom_client', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => 'sanitize_text_field', // Fonction native WP qui supprime les balises HTML malveillantes
    ]);

    // 3. Champ pour la Date de l'avis (Texte simple pour la flexibilité)
    register_post_meta( 'avis_client', '_ac_date_avis', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // 4. Champ pour la Source de l'avis (Google, Trustpilot, Manuel…)
    register_post_meta( 'avis_client', '_ac_source', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // 5. Champ "Achat vérifié" (case à cocher)
    register_post_meta( 'avis_client', '_ac_verified', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'boolean',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => function( $value ) {
            return (bool) $value;
        },
    ]);

    // 6. Préparation V2 : Identifiant externe (ex: ID de l'avis chez Google)
    register_post_meta( 'avis_client', '_ac_id_externe', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => 'sanitize_text_field',
    ]);

    // 7. Préparation V2 : Lien externe (ex: URL de l'avis original sur Google/Trustpilot)
    register_post_meta( 'avis_client', '_ac_lien_externe', [
        'show_in_rest' => true,
        'single'       => true,
        'type'         => 'string',
        'auth_callback' => $auth_callback,
        'sanitize_callback' => 'esc_url_raw',
    ]);

}
add_action( 'init', 'ac_enregistrer_meta_avis' );

/**
 * ÉTAPE 4 : Chargement des classes métier
 * On charge les fichiers qui gèrent la metabox d'administration et la sécurité
 * de la sauvegarde des champs personnalisés.
 */
require_once __DIR__ . '/includes/class-avis-meta.php';
require_once __DIR__ . '/includes/class-avis-security.php';
require_once __DIR__ . '/includes/class-avis-patterns.php';
require_once __DIR__ . '/includes/class-avis-uploads.php';
require_once __DIR__ . '/includes/class-avis-admin.php';

// Instanciation des classes (les hooks internes se déclenchent via __construct)
new AC_Avis_Meta();
new AC_Avis_Security();
new AC_Avis_Patterns();
new AC_Avis_Uploads();
new AC_Avis_Admin();


/**
 * ÉTAPE 5 : Enregistrement des blocs Gutenberg
 *
 * Architecture (v2) : 7 blocs imbriqués (ac/avis-query + 6 blocs enfants)
 * Architecture inspirée de la Boucle de Requête native WordPress.
 */
function ac_enregistrer_blocs() {

    // ── Nouveaux blocs (v2 — architecture inner blocks) ──

    // Bloc conteneur principal : gère la requête et le layout
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-query' );

    // Modèle de carte : répété pour chaque avis, stylisable via sidebar native
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-template' );

    // Blocs enfants : chaque élément de la carte est un bloc indépendant
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-avatar' );    // Image / avatar
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-rating' );    // Étoiles de notation
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-title' );     // Titre de l'avis
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-content' );   // Corps du témoignage
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-signature' ); // Auteur + Date
    
    // Bloc Formulaire
    register_block_type_from_metadata( __DIR__ . '/src/blocks/avis-form' );      // Formulaire de récolte
}
add_action( 'init', 'ac_enregistrer_blocs' );


/**
 * ÉTAPE 6 : Forcer le chargement des styles dans l'éditeur
 * Assure que le rendu en direct (ServerSideRender) dispose du bon CSS
 * même sans l'étape de compilation de webpack/block.json.
 */
function ac_forcer_styles_editeur() {
    wp_enqueue_style(
        'ac-bloc-avis-style-editor',
        plugins_url( 'src/assets/css/style.css', __FILE__ ),
        [],
        filemtime( plugin_dir_path( __FILE__ ) . 'src/assets/css/style.css' )
    );
}
add_action( 'enqueue_block_editor_assets', 'ac_forcer_styles_editeur', 99 );

/**
 * ÉTAPE 7 : Chargement du JS front-end dans l'éditeur (iframe Gutenberg)
 */
function ac_forcer_scripts_iframe_editeur() {
    if ( is_admin() ) {
        wp_enqueue_script(
            'ac-scripts-editeur',
            plugin_dir_url( __FILE__ ) . 'src/assets/js/view.js',
            [],
            filemtime( plugin_dir_path( __FILE__ ) . 'src/assets/js/view.js' ),
            true
        );
    }
}
add_action( 'enqueue_block_assets', 'ac_forcer_scripts_iframe_editeur', 99 );

/**
 * ÉTAPE 8 : REST API pour la soumission du formulaire d'avis
 */
add_action( 'rest_api_init', function () {
    register_rest_route( 'avis-clients/v1', '/submit', [
        'methods'             => 'POST',
        'callback'            => 'ac_handle_avis_submission',
        // Endpoint volontairement public : n'importe quel visiteur peut soumettre un avis.
        // La protection anti-spam repose sur le honeypot vérifié côté serveur dans le callback.
        'permission_callback' => '__return_true',
    ] );
} );

function ac_handle_avis_submission( WP_REST_Request $request ) {
    // ── Anti-abus : limite de fréquence par IP ──
    // Le honeypot ci-dessous protège des bots simples, mais rien n'empêchait
    // jusqu'ici un script d'envoyer des centaines de requêtes d'affilée sur
    // cet endpoint volontairement public. Limite simple par transient :
    // suffisante pour ce volume, pas un remplacement à un vrai reCAPTCHA/WAF
    // si le spam devient un problème réel.
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
    if ( $ip ) {
        $cle_limite = 'ac_rate_' . md5( $ip );
        $nb_envois  = (int) get_transient( $cle_limite );
        if ( $nb_envois >= 5 ) {
            return new WP_Error(
                'too_many_requests',
                __( 'Trop de soumissions depuis cette adresse. Réessayez plus tard.', 'avis-clients' ),
                [ 'status' => 429 ]
            );
        }
        set_transient( $cle_limite, $nb_envois + 1, 10 * MINUTE_IN_SECONDS );
    }

    // get_params() fonctionne aussi bien pour un corps JSON que pour un
    // envoi multipart/form-data (nécessaire depuis que le formulaire envoie
    // la photo en pièce jointe, cf. ac_photo plus bas).
    $params = $request->get_params();

    // Honeypot anti-spam : ce champ est caché dans le formulaire, un humain le laisse vide.
    // S'il est rempli (bot), on renvoie une réponse "succès" factice sans rien enregistrer,
    // pour ne pas indiquer au bot que sa soumission a été détectée.
    if ( ! empty( $params['ac_website'] ) ) {
        return rest_ensure_response([
            'success' => true,
            'message' => 'Avis enregistré en brouillon.'
        ]);
    }

    $note    = isset( $params['ac_note'] ) ? intval( $params['ac_note'] ) : 0;
    $nom     = isset( $params['ac_nom'] ) ? sanitize_text_field( $params['ac_nom'] ) : '';
    $content = isset( $params['ac_content'] ) ? sanitize_textarea_field( $params['ac_content'] ) : '';

    // Longueurs maximales raisonnables : un payload de plusieurs Mo n'a
    // aucune raison légitime d'arriver ici (aucune limite n'existait avant).
    $nom     = mb_substr( $nom, 0, 100 );
    $content = mb_substr( $content, 0, 5000 );

    if ( $note < 1 || $note > 5 || empty( $nom ) || empty( $content ) ) {
        return new WP_Error( 'invalid_data', 'Veuillez remplir tous les champs obligatoires.', [ 'status' => 400 ] );
    }

    // Création du post en brouillon
    $post_id = wp_insert_post([
        'post_type'    => 'avis_client',
        'post_title'   => 'Avis de ' . $nom,
        'post_content' => $content,
        'post_status'  => 'draft',
    ]);

    if ( is_wp_error( $post_id ) ) {
        return new WP_Error( 'db_error', 'Erreur lors de la sauvegarde.', [ 'status' => 500 ] );
    }

    update_post_meta( $post_id, '_ac_note', $note );
    update_post_meta( $post_id, '_ac_nom_client', $nom );
    update_post_meta( $post_id, '_ac_date_avis', current_time( 'Y-m-d' ) );

    // Marqué comme provenant du formulaire front-end
    update_post_meta( $post_id, '_ac_source', 'Site' );

    // Photo facultative envoyée avec le formulaire (image mise en avant).
    $fichiers = $request->get_file_params();
    if ( ! empty( $fichiers['ac_photo'] ) && UPLOAD_ERR_NO_FILE !== $fichiers['ac_photo']['error'] ) {
        ac_traiter_photo_avis( $post_id, $fichiers['ac_photo'] );
    }

    ac_notifier_nouvel_avis( $post_id, $nom, $note, $content );

    return rest_ensure_response([
        'success' => true,
        'message' => 'Avis enregistré en brouillon.'
    ]);
}

/**
 * Prévient l'administrateur par email qu'un nouvel avis attend une
 * relecture. Sans ça, une soumission via le formulaire pouvait passer
 * totalement inaperçue (statut brouillon silencieux).
 *
 * @param int    $post_id ID de l'avis créé.
 * @param string $nom     Nom du client (déjà nettoyé).
 * @param int    $note    Note sur 5.
 * @param string $content Contenu du témoignage (déjà nettoyé).
 */
function ac_notifier_nouvel_avis( $post_id, $nom, $note, $content ) {
    // Filtrable pour rediriger/désactiver la notification sans toucher au code.
    $destinataire = apply_filters( 'ac_avis_notification_email', get_option( 'admin_email' ) );
    if ( ! $destinataire ) {
        return;
    }

    $sujet = sprintf(
        /* translators: 1: nom du site, 2: nom du client */
        __( '[%1$s] Nouvel avis à valider de %2$s', 'avis-clients' ),
        get_bloginfo( 'name' ),
        $nom
    );

    $message = sprintf(
        "%1\$s\n\n%2\$s : %3\$d/5\n\n%4\$s\n\n%5\$s\n%6\$s",
        __( 'Un nouvel avis vient d\'être soumis via le formulaire du site.', 'avis-clients' ),
        __( 'Note', 'avis-clients' ),
        $note,
        $content,
        __( 'Valider ou modifier cet avis :', 'avis-clients' ),
        get_edit_post_link( $post_id, 'raw' )
    );

    wp_mail( $destinataire, $sujet, $message );
}

/**
 * Traite la photo facultative envoyée avec le formulaire public et la
 * définit comme image mise en avant de l'avis créé.
 *
 * Endpoint volontairement public : contrôles stricts avant tout traitement
 * (taille, extension ET type MIME réel du contenu, pas seulement déclaré
 * par le navigateur) puisque n'importe quel visiteur peut appeler cette route.
 *
 * @param int   $post_id ID de l'avis créé.
 * @param array $fichier Entrée correspondante de $request->get_file_params().
 */
function ac_traiter_photo_avis( $post_id, $fichier ) {
    if ( UPLOAD_ERR_OK !== $fichier['error'] ) {
        return;
    }

    // 2 Mo maximum : une photo de profil n'a aucune raison de dépasser ça.
    $taille_max = 2 * MB_IN_BYTES;
    if ( $fichier['size'] > $taille_max ) {
        return;
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    // Vérifie le type réel du contenu (pas seulement l'extension déclarée
    // par le navigateur) : seules les images sont acceptées, jamais de SVG
    // sur un endpoint public (voir includes/class-avis-uploads.php pour
    // l'upload SVG, réservé lui aux administrateurs).
    $types_autorises = [ 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ];
    $filetype = wp_check_filetype_and_ext( $fichier['tmp_name'], $fichier['name'], $types_autorises );
    if ( empty( $filetype['ext'] ) || empty( $filetype['type'] ) ) {
        return;
    }

    $upload = wp_handle_upload( $fichier, [ 'test_form' => false, 'mimes' => $types_autorises ] );
    if ( empty( $upload['file'] ) || ! empty( $upload['error'] ) ) {
        return;
    }

    $attachment_id = wp_insert_attachment( [
        'post_mime_type' => $upload['type'],
        'post_title'     => sanitize_file_name( $fichier['name'] ),
        'post_status'    => 'inherit',
        'post_parent'    => $post_id,
    ], $upload['file'], $post_id );

    if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
        return;
    }

    wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $upload['file'] ) );
    set_post_thumbnail( $post_id, $attachment_id );
}